'use client'

import { useEffect } from 'react'
import { Button } from '@/components/ui/Button'

/**
 * Error boundary untuk menangani error di aplikasi
 * Dengan pesan yang ramah untuk anak-anak
 */
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string }
  reset: () => void
}) {
  useEffect(() => {
    // Log error ke console untuk debugging
    console.error('Error:', error)
  }, [error])

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="text-center max-w-md">
        <div className="text-8xl mb-6">😢</div>
        <h1 className="text-heading-1 font-bold text-primary mb-4">
          Ada yang Salah
        </h1>
        <p className="text-body-large text-text-secondary mb-8">
          Maaf, terjadi kesalahan. Coba lagi ya!
        </p>
        <Button size="lg" onClick={reset}>
          Coba Lagi
        </Button>
      </div>
    </div>
  )
}
