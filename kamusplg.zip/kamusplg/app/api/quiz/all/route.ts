import { NextResponse } from 'next/server'
import { getAllQuestions } from '@/services/quizService'

/**
 * GET /api/quiz/all
 * Mengambil semua soal kuis (untuk admin)
 */
export async function GET() {
  try {
    const questions = await getAllQuestions()
    return NextResponse.json(questions)
  } catch (error) {
    console.error('Error in GET /api/quiz/all:', error)
    return NextResponse.json(
      { error: 'Gagal mengambil soal kuis' },
      { status: 500 }
    )
  }
}
