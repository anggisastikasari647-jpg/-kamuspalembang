import { NextRequest, NextResponse } from 'next/server'
import { getRandomQuestions } from '@/services/quizService'

/**
 * GET /api/quiz/random
 * Query params:
 * - limit: jumlah soal (default 5)
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const limit = parseInt(searchParams.get('limit') || '5', 10)
    
    const questions = await getRandomQuestions(limit)
    return NextResponse.json(questions)
  } catch (error) {
    console.error('Error in GET /api/quiz/random:', error)
    return NextResponse.json(
      { error: 'Gagal mengambil soal kuis' },
      { status: 500 }
    )
  }
}
