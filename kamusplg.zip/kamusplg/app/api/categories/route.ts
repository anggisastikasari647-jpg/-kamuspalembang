import { NextResponse } from 'next/server'
import { getAllCategories } from '@/services/categoryService'

/**
 * GET /api/categories
 * Mengambil semua kategori (publik)
 */
export async function GET() {
  try {
    const categories = await getAllCategories()
    return NextResponse.json(categories)
  } catch (error) {
    console.error('Error in GET /api/categories:', error)
    return NextResponse.json(
      { error: 'Gagal mengambil data kategori' },
      { status: 500 }
    )
  }
}
