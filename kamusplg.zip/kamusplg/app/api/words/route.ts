import { NextRequest, NextResponse } from 'next/server'
import { getAllWords, searchWordsWithCategory } from '@/services/wordService'

/**
 * GET /api/words
 * Query params:
 * - q: search query
 * - category: category id
 */
export async function GET(request: NextRequest) {
  try {
    const searchParams = request.nextUrl.searchParams
    const query = searchParams.get('q') || ''
    const categoryId = searchParams.get('category')
    
    let words
    
    if (query || categoryId) {
      words = await searchWordsWithCategory(
        query,
        categoryId || undefined
      )
    } else {
      words = await getAllWords()
    }
    
    return NextResponse.json(words)
  } catch (error) {
    console.error('Error in GET /api/words:', error)
    return NextResponse.json(
      { error: 'Gagal mengambil data kosakata' },
      { status: 500 }
    )
  }
}
