import Link from 'next/link'
import { Button } from '@/components/ui/Button'

/**
 * Halaman 404 - Not Found
 * Dengan pesan yang ramah untuk anak-anak
 */
export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="text-center max-w-md">
        <div className="text-8xl mb-6">😕</div>
        <h1 className="text-heading-1 font-bold text-primary mb-4">
          Halaman Tidak Ditemukan
        </h1>
        <p className="text-body-large text-text-secondary mb-8">
          Maaf, halaman yang kamu cari tidak ada. Yuk kembali ke beranda!
        </p>
        <Link href="/">
          <Button size="lg">
            Kembali ke Beranda
          </Button>
        </Link>
      </div>
    </div>
  )
}
