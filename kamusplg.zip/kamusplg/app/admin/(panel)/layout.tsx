import { redirect } from 'next/navigation'
import { AdminSidebar } from '@/components/admin/AdminSidebar'
import { getCurrentUser } from '@/services/authService'
import { createClient } from '@/lib/supabase/server'
import { Button } from '@/components/ui/Button'

/**
 * Layout untuk admin panel
 * Proteksi: hanya user terautentikasi yang bisa akses
 */
export default async function AdminPanelLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const user = await getCurrentUser()
  
  if (!user) {
    redirect('/admin/login')
  }
  
  return (
    <div className="flex min-h-screen">
      <AdminSidebar />
      
      <div className="flex-1 bg-background">
        {/* Header */}
        <header className="bg-background-surface border-b border-border p-4">
          <div className="flex items-center justify-between">
            <h2 className="text-heading-3 font-bold text-text-primary">
              Selamat datang, {user.email}
            </h2>
            
            <form action={async () => {
              'use server'
              const supabase = await createClient()
              await supabase.auth.signOut()
              redirect('/admin/login')
            }}>
              <Button type="submit" variant="outline" size="sm">
                Keluar
              </Button>
            </form>
          </div>
        </header>
        
        {/* Content */}
        <main className="p-6">
          {children}
        </main>
      </div>
    </div>
  )
}
