'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Modal, ConfirmDialog } from '@/components/ui/Modal'
import { EmptyState } from '@/components/ui/EmptyState'
import type { QuizQuestionWithOptions, Category } from '@/types'
import { createQuestionAction, updateQuestionAction, deleteQuestionAction } from './actions'

/**
 * Halaman Kelola Soal Kuis
 */
export default function SoalPage() {
  const [questions, setQuestions] = useState<QuizQuestionWithOptions[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingQuestion, setEditingQuestion] = useState<QuizQuestionWithOptions | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  
  useEffect(() => {
    fetchData()
  }, [])
  
  const fetchData = async () => {
    setIsLoading(true)
    const [questionsRes, categoriesRes] = await Promise.all([
      fetch('/api/quiz/all'),
      fetch('/api/categories'),
    ])
    
    const [questionsData, categoriesData] = await Promise.all([
      questionsRes.json(),
      categoriesRes.json(),
    ])
    
    setQuestions(questionsData)
    setCategories(categoriesData)
    setIsLoading(false)
  }
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    const formData = new FormData(e.currentTarget)
    
    const result = editingQuestion
      ? await updateQuestionAction(editingQuestion.id, formData)
      : await createQuestionAction(formData)
    
    if (result.error) {
      alert(result.error)
    } else {
      setShowModal(false)
      setEditingQuestion(null)
      fetchData()
    }
    
    setIsSubmitting(false)
  }
  
  const handleDelete = async () => {
    if (!deleteId) return
    
    setIsSubmitting(true)
    const result = await deleteQuestionAction(deleteId)
    
    if (result.error) {
      alert(result.error)
    } else {
      fetchData()
    }
    
    setIsSubmitting(false)
    setDeleteId(null)
  }
  
  const openAddModal = () => {
    setEditingQuestion(null)
    setShowModal(true)
  }
  
  const openEditModal = (question: QuizQuestionWithOptions) => {
    setEditingQuestion(question)
    setShowModal(true)
  }
  
  const categoryOptions = [
    { value: '', label: 'Tanpa Kategori' },
    ...categories.map(cat => ({ value: cat.id, label: cat.name })),
  ]
  
  // Untuk editing, cari opsi mana yang correct
  const correctAnswer = editingQuestion?.options.find(opt => opt.is_correct)
  const correctIndex = editingQuestion?.options.indexOf(correctAnswer!) ?? -1
  const correctLetter = correctIndex >= 0 ? String.fromCharCode(97 + correctIndex) : 'a' // a, b, c, d
  
  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-heading-1 font-bold text-text-primary">
            Kelola Soal Kuis
          </h1>
          <p className="text-body text-text-secondary">
            Tambah, ubah, atau hapus soal kuis
          </p>
        </div>
        
        <Button size="lg" onClick={openAddModal}>
          ➕ Tambah Soal
        </Button>
      </div>
      
      {/* List */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="text-4xl mb-4">⏳</div>
          <p className="text-body text-text-secondary">Memuat data...</p>
        </div>
      ) : questions.length === 0 ? (
        <EmptyState
          title="Belum Ada Soal"
          description="Klik tombol Tambah Soal untuk membuat soal kuis baru"
          icon="❓"
        />
      ) : (
        <div className="space-y-4">
          {questions.map((question) => {
            const correctOpt = question.options.find(opt => opt.is_correct)
            
            return (
              <div
                key={question.id}
                className="bg-background-surface rounded-card border border-border p-6"
              >
                <div className="flex items-start justify-between mb-4">
                  <h3 className="text-heading-3 font-bold text-text-primary flex-1">
                    {question.question}
                  </h3>
                  <div className="flex items-center gap-2 ml-4">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => openEditModal(question)}
                    >
                      ✏️ Ubah
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setDeleteId(question.id)}
                    >
                      🗑️ Hapus
                    </Button>
                  </div>
                </div>
                
                <div className="space-y-2 mb-3">
                  {question.options.map((option, index) => (
                    <div
                      key={option.id}
                      className={`p-3 rounded-button border ${
                        option.is_correct
                          ? 'bg-green-100 border-green-500 text-green-900'
                          : 'bg-background border-border'
                      }`}
                    >
                      <span className="font-bold mr-2">
                        {String.fromCharCode(65 + index)}.
                      </span>
                      {option.option_text}
                      {option.is_correct && (
                        <span className="ml-2 text-green-600">✓ Benar</span>
                      )}
                    </div>
                  ))}
                </div>
                
                {question.category_id && (
                  <p className="text-caption text-text-secondary">
                    Kategori: {(question as any).category?.name || 'N/A'}
                  </p>
                )}
              </div>
            )
          })}
        </div>
      )}
      
      {/* Form Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingQuestion ? 'Ubah Soal' : 'Tambah Soal'}
        size="lg"
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            name="question"
            label="Pertanyaan *"
            placeholder="Contoh: Apa arti kata 'nian' dalam Bahasa Indonesia?"
            defaultValue={editingQuestion?.question || ''}
            required
          />
          
          <Select
            name="category_id"
            label="Kategori (Opsional)"
            options={categoryOptions}
            defaultValue={editingQuestion?.category_id || ''}
          />
          
          <div className="border-t border-border pt-4">
            <h3 className="text-heading-3 font-bold text-text-primary mb-4">
              Opsi Jawaban (4 opsi, 1 benar)
            </h3>
            
            <div className="space-y-3">
              <Input
                name="option_a"
                label="A. *"
                placeholder="Opsi A"
                defaultValue={editingQuestion?.options[0]?.option_text || ''}
                required
              />
              
              <Input
                name="option_b"
                label="B. *"
                placeholder="Opsi B"
                defaultValue={editingQuestion?.options[1]?.option_text || ''}
                required
              />
              
              <Input
                name="option_c"
                label="C. *"
                placeholder="Opsi C"
                defaultValue={editingQuestion?.options[2]?.option_text || ''}
                required
              />
              
              <Input
                name="option_d"
                label="D. *"
                placeholder="Opsi D"
                defaultValue={editingQuestion?.options[3]?.option_text || ''}
                required
              />
            </div>
          </div>
          
          <div className="border-t border-border pt-4">
            <label className="block text-body font-bold text-text-primary mb-3">
              Jawaban yang Benar *
            </label>
            
            <div className="space-y-2">
              {['a', 'b', 'c', 'd'].map((letter) => (
                <label
                  key={letter}
                  className="flex items-center gap-3 p-3 rounded-button border-2 border-border hover:border-primary cursor-pointer transition-colors"
                >
                  <input
                    type="radio"
                    name="correct_answer"
                    value={letter}
                    defaultChecked={editingQuestion ? correctLetter === letter : letter === 'a'}
                    required
                    className="w-5 h-5"
                  />
                  <span className="text-body font-medium">
                    Opsi {letter.toUpperCase()}
                  </span>
                </label>
              ))}
            </div>
          </div>
          
          <div className="flex items-center gap-3 pt-4">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Menyimpan...' : '💾 Simpan'}
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => setShowModal(false)}
              disabled={isSubmitting}
            >
              Batal
            </Button>
          </div>
        </form>
      </Modal>
      
      {/* Confirm Delete */}
      <ConfirmDialog
        isOpen={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Hapus Soal"
        description="Apakah Anda yakin ingin menghapus soal ini?"
        isLoading={isSubmitting}
      />
    </div>
  )
}
