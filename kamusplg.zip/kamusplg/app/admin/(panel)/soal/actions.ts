'use server'

import { revalidatePath } from 'next/cache'
import { quizQuestionSchema } from '@/lib/validators/question'
import { createQuestion, updateQuestion, deleteQuestion } from '@/services/quizService'

/**
 * Server Action untuk membuat soal kuis baru
 */
export async function createQuestionAction(formData: FormData) {
  try {
    const question = formData.get('question') as string
    const category_id = formData.get('category_id') as string || null
    
    const options = [
      {
        option_text: formData.get('option_a') as string,
        is_correct: formData.get('correct_answer') === 'a',
      },
      {
        option_text: formData.get('option_b') as string,
        is_correct: formData.get('correct_answer') === 'b',
      },
      {
        option_text: formData.get('option_c') as string,
        is_correct: formData.get('correct_answer') === 'c',
      },
      {
        option_text: formData.get('option_d') as string,
        is_correct: formData.get('correct_answer') === 'd',
      },
    ]
    
    const data = { question, category_id, options }
    const validated = quizQuestionSchema.parse(data)
    
    await createQuestion(
      { question: validated.question, category_id: validated.category_id },
      validated.options
    )
    
    revalidatePath('/admin/soal')
    return { success: true }
  } catch (error: any) {
    console.error('Error creating question:', error)
    return {
      error: error.message || 'Gagal membuat soal',
    }
  }
}

/**
 * Server Action untuk mengupdate soal kuis
 */
export async function updateQuestionAction(id: string, formData: FormData) {
  try {
    const question = formData.get('question') as string
    const category_id = formData.get('category_id') as string || null
    
    const options = [
      {
        option_text: formData.get('option_a') as string,
        is_correct: formData.get('correct_answer') === 'a',
      },
      {
        option_text: formData.get('option_b') as string,
        is_correct: formData.get('correct_answer') === 'b',
      },
      {
        option_text: formData.get('option_c') as string,
        is_correct: formData.get('correct_answer') === 'c',
      },
      {
        option_text: formData.get('option_d') as string,
        is_correct: formData.get('correct_answer') === 'd',
      },
    ]
    
    const data = { question, category_id, options }
    const validated = quizQuestionSchema.parse(data)
    
    await updateQuestion(
      id,
      { question: validated.question, category_id: validated.category_id },
      validated.options
    )
    
    revalidatePath('/admin/soal')
    return { success: true }
  } catch (error: any) {
    console.error('Error updating question:', error)
    return {
      error: error.message || 'Gagal mengupdate soal',
    }
  }
}

/**
 * Server Action untuk menghapus soal kuis
 */
export async function deleteQuestionAction(id: string) {
  try {
    await deleteQuestion(id)
    revalidatePath('/admin/soal')
    return { success: true }
  } catch (error: any) {
    console.error('Error deleting question:', error)
    return {
      error: error.message || 'Gagal menghapus soal',
    }
  }
}
