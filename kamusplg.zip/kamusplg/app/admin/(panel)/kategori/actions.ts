'use server'

import { revalidatePath } from 'next/cache'
import { categorySchema } from '@/lib/validators/category'
import { createCategory, updateCategory, deleteCategory } from '@/services/categoryService'
import { slugify } from '@/lib/utils/slugify'

/**
 * Server Action untuk membuat kategori baru
 */
export async function createCategoryAction(formData: FormData) {
  try {
    const name = formData.get('name') as string
    const sort_order = parseInt(formData.get('sort_order') as string || '0', 10)
    
    const data = {
      name,
      slug: slugify(name),
      sort_order,
    }
    
    const validated = categorySchema.parse(data)
    await createCategory(validated)
    
    revalidatePath('/admin/kategori')
    return { success: true }
  } catch (error: any) {
    console.error('Error creating category:', error)
    return {
      error: error.message || 'Gagal membuat kategori',
    }
  }
}

/**
 * Server Action untuk mengupdate kategori
 */
export async function updateCategoryAction(id: string, formData: FormData) {
  try {
    const name = formData.get('name') as string
    const sort_order = parseInt(formData.get('sort_order') as string || '0', 10)
    
    const data = {
      name,
      slug: slugify(name),
      sort_order,
    }
    
    const validated = categorySchema.parse(data)
    await updateCategory(id, validated)
    
    revalidatePath('/admin/kategori')
    return { success: true }
  } catch (error: any) {
    console.error('Error updating category:', error)
    return {
      error: error.message || 'Gagal mengupdate kategori',
    }
  }
}

/**
 * Server Action untuk menghapus kategori
 */
export async function deleteCategoryAction(id: string) {
  try {
    await deleteCategory(id)
    revalidatePath('/admin/kategori')
    return { success: true }
  } catch (error: any) {
    console.error('Error deleting category:', error)
    return {
      error: error.message || 'Gagal menghapus kategori',
    }
  }
}
