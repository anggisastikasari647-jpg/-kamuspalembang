'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Modal, ConfirmDialog } from '@/components/ui/Modal'
import { EmptyState } from '@/components/ui/EmptyState'
import type { Category } from '@/types'
import { createCategoryAction, updateCategoryAction, deleteCategoryAction } from './actions'

type CategoryWithCount = Category & { word_count?: number }

/**
 * Halaman Kelola Kategori
 */
export default function KategoriPage() {
  const [categories, setCategories] = useState<CategoryWithCount[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editingCategory, setEditingCategory] = useState<CategoryWithCount | null>(null)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [isSubmitting, setIsSubmitting] = useState(false)
  
  useEffect(() => {
    fetchCategories()
  }, [])
  
  const fetchCategories = async () => {
    setIsLoading(true)
    const res = await fetch('/api/categories')
    const data = await res.json()
    setCategories(data)
    setIsLoading(false)
  }
  
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    setIsSubmitting(true)
    
    const formData = new FormData(e.currentTarget)
    
    const result = editingCategory
      ? await updateCategoryAction(editingCategory.id, formData)
      : await createCategoryAction(formData)
    
    if (result.error) {
      alert(result.error)
    } else {
      setShowModal(false)
      setEditingCategory(null)
      fetchCategories()
    }
    
    setIsSubmitting(false)
  }
  
  const handleDelete = async () => {
    if (!deleteId) return
    
    setIsSubmitting(true)
    const result = await deleteCategoryAction(deleteId)
    
    if (result.error) {
      alert(result.error)
    } else {
      fetchCategories()
    }
    
    setIsSubmitting(false)
    setDeleteId(null)
  }
  
  const openAddModal = () => {
    setEditingCategory(null)
    setShowModal(true)
  }
  
  const openEditModal = (category: CategoryWithCount) => {
    setEditingCategory(category)
    setShowModal(true)
  }
  
  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-heading-1 font-bold text-text-primary">
            Kelola Kategori
          </h1>
          <p className="text-body text-text-secondary">
            Tambah, ubah, atau hapus kategori kosakata
          </p>
        </div>
        
        <Button size="lg" onClick={openAddModal}>
          ➕ Tambah Kategori
        </Button>
      </div>
      
      {/* Table */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="text-4xl mb-4">⏳</div>
          <p className="text-body text-text-secondary">Memuat data...</p>
        </div>
      ) : categories.length === 0 ? (
        <EmptyState
          title="Belum Ada Kategori"
          description="Klik tombol Tambah Kategori untuk membuat kategori baru"
          icon="🏷️"
        />
      ) : (
        <div className="bg-background-surface rounded-card border border-border overflow-hidden">
          <table className="w-full">
            <thead className="bg-border">
              <tr>
                <th className="px-4 py-3 text-left text-body font-bold">Nama Kategori</th>
                <th className="px-4 py-3 text-left text-body font-bold">Slug</th>
                <th className="px-4 py-3 text-left text-body font-bold">Jumlah Kata</th>
                <th className="px-4 py-3 text-left text-body font-bold">Urutan</th>
                <th className="px-4 py-3 text-right text-body font-bold">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {categories.map((category) => (
                <tr key={category.id} className="hover:bg-background">
                  <td className="px-4 py-3 text-body font-medium text-primary">
                    {category.name}
                  </td>
                  <td className="px-4 py-3 text-body text-text-secondary">
                    {category.slug}
                  </td>
                  <td className="px-4 py-3 text-body">
                    {category.word_count || 0} kata
                  </td>
                  <td className="px-4 py-3 text-body">
                    {category.sort_order}
                  </td>
                  <td className="px-4 py-3 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => openEditModal(category)}
                      >
                        ✏️ Ubah
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setDeleteId(category.id)}
                      >
                        🗑️ Hapus
                      </Button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      
      {/* Form Modal */}
      <Modal
        isOpen={showModal}
        onClose={() => setShowModal(false)}
        title={editingCategory ? 'Ubah Kategori' : 'Tambah Kategori'}
      >
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            name="name"
            label="Nama Kategori *"
            placeholder="Contoh: Sehari-hari"
            defaultValue={editingCategory?.name || ''}
            required
          />
          
          <Input
            name="sort_order"
            label="Urutan *"
            type="number"
            placeholder="0"
            defaultValue={editingCategory?.sort_order?.toString() || '0'}
            required
          />
          
          <p className="text-caption text-text-secondary">
            Slug akan dibuat otomatis dari nama kategori
          </p>
          
          <div className="flex items-center gap-3 pt-4">
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Menyimpan...' : '💾 Simpan'}
            </Button>
            <Button
              type="button"
              variant="secondary"
              onClick={() => setShowModal(false)}
              disabled={isSubmitting}
            >
              Batal
            </Button>
          </div>
        </form>
      </Modal>
      
      {/* Confirm Delete */}
      <ConfirmDialog
        isOpen={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Hapus Kategori"
        description="Apakah Anda yakin? Kategori yang masih memiliki kata tidak dapat dihapus."
        isLoading={isSubmitting}
      />
    </div>
  )
}
