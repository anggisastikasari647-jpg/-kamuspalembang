'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { ConfirmDialog } from '@/components/ui/Modal'
import { EmptyState } from '@/components/ui/EmptyState'
import type { WordWithCategory } from '@/types'
import { deleteWordAction } from './actions'

/**
 * Halaman Kelola Kosakata
 * Menampilkan tabel kosakata dengan aksi ubah/hapus
 */
export default function KosakataPage() {
  const [words, setWords] = useState<WordWithCategory[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [isLoading, setIsLoading] = useState(true)
  const [deleteId, setDeleteId] = useState<string | null>(null)
  const [isDeleting, setIsDeleting] = useState(false)
  
  // Fetch words
  useEffect(() => {
    fetchWords()
  }, [searchQuery])
  
  const fetchWords = async () => {
    setIsLoading(true)
    const params = new URLSearchParams()
    if (searchQuery) params.set('q', searchQuery)
    
    const res = await fetch(`/api/words?${params.toString()}`)
    const data = await res.json()
    setWords(data)
    setIsLoading(false)
  }
  
  const handleDelete = async () => {
    if (!deleteId) return
    
    setIsDeleting(true)
    const result = await deleteWordAction(deleteId)
    
    if (result.error) {
      alert(result.error)
    } else {
      fetchWords()
    }
    
    setIsDeleting(false)
    setDeleteId(null)
  }
  
  return (
    <div>
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-heading-1 font-bold text-text-primary">
            Kelola Kosakata
          </h1>
          <p className="text-body text-text-secondary">
            Tambah, ubah, atau hapus kosakata Bahasa Palembang
          </p>
        </div>
        
        <Link href="/admin/kosakata/baru">
          <Button size="lg">
            ➕ Tambah Kata
          </Button>
        </Link>
      </div>
      
      {/* Search */}
      <div className="mb-6">
        <Input
          type="search"
          placeholder="Cari kata..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      
      {/* Table */}
      {isLoading ? (
        <div className="text-center py-12">
          <div className="text-4xl mb-4">⏳</div>
          <p className="text-body text-text-secondary">Memuat data...</p>
        </div>
      ) : words.length === 0 ? (
        <EmptyState
          title="Belum Ada Kosakata"
          description="Klik tombol Tambah Kata untuk membuat kosakata baru"
          icon="📝"
        />
      ) : (
        <div className="bg-background-surface rounded-card border border-border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-border">
                <tr>
                  <th className="px-4 py-3 text-left text-body font-bold text-text-primary">
                    Kata Palembang
                  </th>
                  <th className="px-4 py-3 text-left text-body font-bold text-text-primary">
                    Arti Indonesia
                  </th>
                  <th className="px-4 py-3 text-left text-body font-bold text-text-primary">
                    Kategori
                  </th>
                  <th className="px-4 py-3 text-right text-body font-bold text-text-primary">
                    Aksi
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {words.map((word) => (
                  <tr key={word.id} className="hover:bg-background transition-colors">
                    <td className="px-4 py-3 text-body font-medium text-primary">
                      {word.palembang}
                    </td>
                    <td className="px-4 py-3 text-body text-text-primary">
                      {word.indonesia}
                    </td>
                    <td className="px-4 py-3">
                      <span className="inline-block px-2 py-1 bg-accent/20 text-accent-dark rounded text-caption font-medium">
                        {word.category.name}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <Link href={`/admin/kosakata/${word.id}/ubah`}>
                          <Button variant="outline" size="sm">
                            ✏️ Ubah
                          </Button>
                        </Link>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setDeleteId(word.id)}
                        >
                          🗑️ Hapus
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
      
      {/* Confirm Delete Dialog */}
      <ConfirmDialog
        isOpen={deleteId !== null}
        onClose={() => setDeleteId(null)}
        onConfirm={handleDelete}
        title="Hapus Kosakata"
        description="Apakah Anda yakin ingin menghapus kosakata ini? Tindakan ini tidak dapat dibatalkan."
        confirmText="Hapus"
        cancelText="Batal"
        isLoading={isDeleting}
      />
    </div>
  )
}
