'use server'

import { revalidatePath } from 'next/cache'
import { redirect } from 'next/navigation'
import { wordSchema } from '@/lib/validators/word'
import { createWord, updateWord, deleteWord } from '@/services/wordService'

/**
 * Server Action untuk membuat kosakata baru
 */
export async function createWordAction(formData: FormData) {
  try {
    const data = {
      palembang: formData.get('palembang') as string,
      indonesia: formData.get('indonesia') as string,
      category_id: formData.get('category_id') as string,
      example_palembang: formData.get('example_palembang') as string || null,
      example_indonesia: formData.get('example_indonesia') as string || null,
    }
    
    // Validasi dengan Zod
    const validated = wordSchema.parse(data)
    
    // Buat kata baru
    await createWord(validated)
    
    revalidatePath('/admin/kosakata')
    redirect('/admin/kosakata')
  } catch (error: any) {
    console.error('Error creating word:', error)
    return {
      error: error.message || 'Gagal membuat kosakata',
    }
  }
}

/**
 * Server Action untuk mengupdate kosakata
 */
export async function updateWordAction(id: string, formData: FormData) {
  try {
    const data = {
      palembang: formData.get('palembang') as string,
      indonesia: formData.get('indonesia') as string,
      category_id: formData.get('category_id') as string,
      example_palembang: formData.get('example_palembang') as string || null,
      example_indonesia: formData.get('example_indonesia') as string || null,
    }
    
    // Validasi dengan Zod
    const validated = wordSchema.parse(data)
    
    // Update kata
    await updateWord(id, validated)
    
    revalidatePath('/admin/kosakata')
    redirect('/admin/kosakata')
  } catch (error: any) {
    console.error('Error updating word:', error)
    return {
      error: error.message || 'Gagal mengupdate kosakata',
    }
  }
}

/**
 * Server Action untuk menghapus kosakata
 */
export async function deleteWordAction(id: string) {
  try {
    await deleteWord(id)
    revalidatePath('/admin/kosakata')
    return { success: true }
  } catch (error: any) {
    console.error('Error deleting word:', error)
    return {
      error: error.message || 'Gagal menghapus kosakata',
    }
  }
}
