import Link from 'next/link'
import { notFound } from 'next/navigation'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Button } from '@/components/ui/Button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import { getAllCategories } from '@/services/categoryService'
import { getWordById } from '@/services/wordService'
import { updateWordAction } from '../../actions'

interface UbahKataPageProps {
  params: Promise<{
    id: string
  }>
}

/**
 * Halaman Form Ubah Kosakata
 */
export default async function UbahKataPage({ params }: UbahKataPageProps) {
  const { id } = await params
  
  const [categories, word] = await Promise.all([
    getAllCategories(),
    getWordById(id),
  ])
  
  if (!word) {
    notFound()
  }
  
  const categoryOptions = categories.map(cat => ({
    value: cat.id,
    label: cat.name,
  }))
  
  return (
    <div className="max-w-2xl">
      {/* Header */}
      <div className="mb-6">
        <Link
          href="/admin/kosakata"
          className="inline-flex items-center text-body text-primary hover:text-primary-dark mb-3"
        >
          <span className="mr-2">←</span> Kembali ke Daftar Kosakata
        </Link>
        
        <h1 className="text-heading-1 font-bold text-text-primary">
          Ubah Kata
        </h1>
        <p className="text-body text-text-secondary">
          Edit informasi kosakata
        </p>
      </div>
      
      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle>Form Kosakata</CardTitle>
        </CardHeader>
        
        <CardContent>
          <form action={updateWordAction.bind(null, id)} className="space-y-4">
            <Input
              name="palembang"
              label="Kata Palembang *"
              defaultValue={word.palembang}
              required
            />
            
            <Input
              name="indonesia"
              label="Arti Indonesia *"
              defaultValue={word.indonesia}
              required
            />
            
            <Select
              name="category_id"
              label="Kategori *"
              options={categoryOptions}
              defaultValue={word.category_id}
              required
            />
            
            <div className="border-t border-border pt-4 mt-6">
              <h3 className="text-heading-3 font-bold text-text-primary mb-4">
                Contoh Kalimat (Opsional)
              </h3>
              
              <div className="space-y-4">
                <Input
                  name="example_palembang"
                  label="Contoh Kalimat Palembang"
                  defaultValue={word.example_palembang || ''}
                />
                
                <Input
                  name="example_indonesia"
                  label="Terjemahan Contoh"
                  defaultValue={word.example_indonesia || ''}
                />
              </div>
            </div>
            
            <div className="flex items-center gap-3 pt-4">
              <Button type="submit" size="lg">
                💾 Simpan Perubahan
              </Button>
              
              <Link href="/admin/kosakata">
                <Button type="button" variant="secondary" size="lg">
                  Batal
                </Button>
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
