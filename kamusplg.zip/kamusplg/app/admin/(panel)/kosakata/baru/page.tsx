import Link from 'next/link'
import { Input } from '@/components/ui/Input'
import { Select } from '@/components/ui/Select'
import { Button } from '@/components/ui/Button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/Card'
import { getAllCategories } from '@/services/categoryService'
import { createWordAction } from '../actions'

/**
 * Halaman Form Tambah Kosakata Baru
 */
export default async function TambahKataPage() {
  const categories = await getAllCategories()
  
  const categoryOptions = categories.map(cat => ({
    value: cat.id,
    label: cat.name,
  }))
  
  return (
    <div className="max-w-2xl">
      {/* Header */}
      <div className="mb-6">
        <Link
          href="/admin/kosakata"
          className="inline-flex items-center text-body text-primary hover:text-primary-dark mb-3"
        >
          <span className="mr-2">←</span> Kembali ke Daftar Kosakata
        </Link>
        
        <h1 className="text-heading-1 font-bold text-text-primary">
          Tambah Kata Baru
        </h1>
        <p className="text-body text-text-secondary">
          Isi form di bawah untuk menambah kosakata baru
        </p>
      </div>
      
      {/* Form */}
      <Card>
        <CardHeader>
          <CardTitle>Form Kosakata</CardTitle>
        </CardHeader>
        
        <CardContent>
          <form action={createWordAction} className="space-y-4">
            <Input
              name="palembang"
              label="Kata Palembang *"
              placeholder="Contoh: nian"
              required
            />
            
            <Input
              name="indonesia"
              label="Arti Indonesia *"
              placeholder="Contoh: sangat"
              required
            />
            
            <Select
              name="category_id"
              label="Kategori *"
              options={categoryOptions}
              required
            />
            
            <div className="border-t border-border pt-4 mt-6">
              <h3 className="text-heading-3 font-bold text-text-primary mb-4">
                Contoh Kalimat (Opsional)
              </h3>
              
              <div className="space-y-4">
                <Input
                  name="example_palembang"
                  label="Contoh Kalimat Palembang"
                  placeholder="Contoh: Panas nian ari ini"
                />
                
                <Input
                  name="example_indonesia"
                  label="Terjemahan Contoh"
                  placeholder="Contoh: Sangat panas hari ini"
                />
              </div>
            </div>
            
            <div className="flex items-center gap-3 pt-4">
              <Button type="submit" size="lg">
                💾 Simpan
              </Button>
              
              <Link href="/admin/kosakata">
                <Button type="button" variant="secondary" size="lg">
                  Batal
                </Button>
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
