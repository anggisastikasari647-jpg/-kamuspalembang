import Link from 'next/link'
import { notFound } from 'next/navigation'
import { WordCard } from '@/components/siswa/WordCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { getCategoryBySlug } from '@/services/categoryService'
import { getWordsByCategory } from '@/services/wordService'

interface KamusKategoriPageProps {
  params: Promise<{
    kategoriSlug: string
  }>
}

/**
 * Halaman Kamus per Kategori
 * Menampilkan semua kata dalam satu kategori
 */
export default async function KamusKategoriPage({ params }: KamusKategoriPageProps) {
  const { kategoriSlug } = await params
  
  const category = await getCategoryBySlug(kategoriSlug)
  
  if (!category) {
    notFound()
  }
  
  const words = await getWordsByCategory(category.id)
  
  return (
    <div className="container-mobile py-6">
      {/* Header */}
      <header className="mb-6">
        <Link
          href="/kamus"
          className="inline-flex items-center text-body text-primary hover:text-primary-dark mb-3"
        >
          <span className="mr-2">←</span> Kembali ke Kamus
        </Link>
        
        <h1 className="text-heading-1 font-extrabold text-primary mb-2">
          {category.name}
        </h1>
        <p className="text-body text-text-secondary">
          {words.length} kata tersedia
        </p>
      </header>
      
      {/* Words list */}
      <div className="space-y-4">
        {words.length === 0 ? (
          <EmptyState
            title="Belum Ada Kata"
            description="Kategori ini belum memiliki kata. Coba kategori lain!"
            icon="📝"
          />
        ) : (
          words.map((word) => (
            <WordCard key={word.id} word={word} />
          ))
        )}
      </div>
    </div>
  )
}
