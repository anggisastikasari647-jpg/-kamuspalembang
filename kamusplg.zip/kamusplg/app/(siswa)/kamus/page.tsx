'use client'

import { useState, useCallback, useEffect } from 'react'
import { Select } from '@/components/ui/Select'
import { SearchBar } from '@/components/siswa/SearchBar'
import { WordCard } from '@/components/siswa/WordCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { WordCardSkeleton } from '@/components/ui/Skeleton'
import type { WordWithCategory, Category } from '@/types'

/**
 * Halaman Kamus
 * Menampilkan daftar kata dengan fitur pencarian dan filter kategori
 */
export default function KamusPage() {
  const [words, setWords] = useState<WordWithCategory[]>([])
  const [categories, setCategories] = useState<Category[]>([])
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedCategory, setSelectedCategory] = useState<string>('all')
  const [isLoading, setIsLoading] = useState(true)
  
  // Fetch categories
  useEffect(() => {
    fetch('/api/categories')
      .then(res => res.json())
      .then(data => setCategories(data))
      .catch(err => console.error('Error fetching categories:', err))
  }, [])
  
  // Fetch words dengan filter
  useEffect(() => {
    setIsLoading(true)
    
    const params = new URLSearchParams()
    if (searchQuery) params.set('q', searchQuery)
    if (selectedCategory !== 'all') params.set('category', selectedCategory)
    
    fetch(`/api/words?${params.toString()}`)
      .then(res => res.json())
      .then(data => {
        setWords(data)
        setIsLoading(false)
      })
      .catch(err => {
        console.error('Error fetching words:', err)
        setIsLoading(false)
      })
  }, [searchQuery, selectedCategory])
  
  const handleSearch = useCallback((query: string) => {
    setSearchQuery(query)
  }, [])
  
  const categoryOptions = [
    { value: 'all', label: 'Semua Kategori' },
    ...categories.map(cat => ({ value: cat.id, label: cat.name })),
  ]
  
  return (
    <div className="container-mobile py-6">
      {/* Header */}
      <header className="mb-6">
        <h1 className="text-heading-1 font-extrabold text-primary mb-2">
          📖 Kamus
        </h1>
        <p className="text-body text-text-secondary">
          Cari dan pelajari kosakata Bahasa Palembang
        </p>
      </header>
      
      {/* Search & Filter */}
      <div className="space-y-4 mb-6">
        <SearchBar
          onSearch={handleSearch}
          placeholder="Cari kata..."
        />
        
        <Select
          options={categoryOptions}
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
          label="Filter Kategori"
        />
      </div>
      
      {/* Results */}
      <div className="space-y-4">
        {isLoading ? (
          // Loading state
          Array.from({ length: 5 }).map((_, i) => (
            <WordCardSkeleton key={i} />
          ))
        ) : words.length === 0 ? (
          // Empty state
          <EmptyState
            title="Kata Tidak Ditemukan"
            description="Coba cari dengan kata lain atau pilih kategori berbeda"
            icon="🔍"
          />
        ) : (
          // Words list
          words.map((word) => (
            <WordCard key={word.id} word={word} />
          ))
        )}
      </div>
    </div>
  )
}
