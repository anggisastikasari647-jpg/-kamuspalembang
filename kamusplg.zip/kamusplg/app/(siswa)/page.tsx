import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { CategoryCard } from '@/components/siswa/CategoryCard'
import { getCategoriesWithWordCount } from '@/services/categoryService'

/**
 * Halaman Beranda Siswa
 * Menampilkan judul, kolom pencarian, kategori, dan tombol kuis
 */
export default async function BerandaPage() {
  const categories = await getCategoriesWithWordCount()
  
  return (
    <div className="container-mobile py-6">
      {/* Header */}
      <header className="text-center mb-8">
        <h1 className="text-heading-1 font-extrabold text-primary mb-2">
          Belajar Baso Pelembang
        </h1>
        <p className="text-body-large text-text-secondary">
          Yuk belajar Bahasa Palembang dengan seru! 🎉
        </p>
      </header>
      
      {/* Search shortcut */}
      <Link href="/kamus" className="block mb-6">
        <div className="w-full px-4 py-4 rounded-button border-2 border-border bg-background-surface text-text-secondary flex items-center gap-3 hover:border-primary transition-colors">
          <span className="text-2xl">🔍</span>
          <span className="text-body">Cari kata di kamus...</span>
        </div>
      </Link>
      
      {/* Kategori */}
      <section className="mb-8">
        <h2 className="text-heading-2 font-bold text-text-primary mb-4">
          Kategori Kata
        </h2>
        <div className="grid grid-cols-2 gap-4">
          {categories.map((category) => (
            <CategoryCard
              key={category.id}
              category={category}
              wordCount={category.word_count}
            />
          ))}
        </div>
      </section>
      
      {/* Tombol Kuis */}
      <section>
        <Link href="/kuis">
          <Button size="lg" variant="accent" fullWidth className="shadow-lg">
            <span className="text-2xl mr-2">🎯</span>
            Main Kuis Sekarang!
          </Button>
        </Link>
      </section>
    </div>
  )
}
