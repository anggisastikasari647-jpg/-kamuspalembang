import { BottomNav } from '@/components/siswa/BottomNav'

/**
 * Layout untuk halaman siswa
 * Termasuk bottom navigation yang sticky
 */
export default function SiswaLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="min-h-screen bg-background pb-24">
      {children}
      <BottomNav />
    </div>
  )
}
