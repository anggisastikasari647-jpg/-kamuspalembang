'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/Button'
import { Card, CardContent } from '@/components/ui/Card'
import { ScoreCircle } from '@/components/siswa/ScoreCircle'
import type { QuizResult } from '@/types'

/**
 * Halaman Hasil Kuis
 * Menampilkan skor, motivasi, dan daftar kesalahan
 */
export default function HasilKuisPage() {
  const router = useRouter()
  const [result, setResult] = useState<QuizResult | null>(null)
  
  useEffect(() => {
    // Ambil hasil dari sessionStorage
    const savedResult = sessionStorage.getItem('quizResult')
    if (savedResult) {
      setResult(JSON.parse(savedResult))
    }
  }, [])
  
  if (!result) {
    return (
      <div className="container-mobile py-6">
        <div className="text-center">
          <div className="text-6xl mb-4">🤔</div>
          <p className="text-body-large text-text-secondary mb-6">
            Tidak ada hasil kuis. Yuk main kuis dulu!
          </p>
          <Link href="/kuis">
            <Button size="lg">Main Kuis</Button>
          </Link>
        </div>
      </div>
    )
  }
  
  const percentage = (result.correctAnswers / result.totalQuestions) * 100
  
  // Kalimat motivasi berdasarkan skor
  let motivation = ''
  let emoji = ''
  
  if (percentage === 100) {
    motivation = 'Sempurna! Kamu luar biasa! 🌟'
    emoji = '🏆'
  } else if (percentage >= 80) {
    motivation = 'Hebat sekali! Kamu sudah pintar! 🎉'
    emoji = '😊'
  } else if (percentage >= 60) {
    motivation = 'Bagus! Terus belajar ya! 💪'
    emoji = '👍'
  } else if (percentage >= 40) {
    motivation = 'Lumayan! Yuk belajar lagi! 📚'
    emoji = '😌'
  } else {
    motivation = 'Jangan menyerah! Coba lagi ya! 🌈'
    emoji = '💪'
  }
  
  const handleUlangi = () => {
    sessionStorage.removeItem('quizResult')
    router.push('/kuis')
  }
  
  return (
    <div className="container-mobile py-6">
      {/* Header */}
      <header className="text-center mb-8">
        <div className="text-6xl mb-4">{emoji}</div>
        <h1 className="text-heading-1 font-extrabold text-primary mb-2">
          Hasil Kuis
        </h1>
        <p className="text-body-large text-text-secondary">
          {motivation}
        </p>
      </header>
      
      {/* Score Circle */}
      <div className="mb-8">
        <ScoreCircle
          correct={result.correctAnswers}
          total={result.totalQuestions}
        />
      </div>
      
      {/* Statistik */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-4xl font-extrabold text-green-600 mb-1">
              {result.correctAnswers}
            </div>
            <p className="text-body text-text-secondary">Benar</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-4xl font-extrabold text-red-600 mb-1">
              {result.totalQuestions - result.correctAnswers}
            </div>
            <p className="text-body text-text-secondary">Salah</p>
          </CardContent>
        </Card>
      </div>
      
      {/* Daftar Kesalahan */}
      {result.incorrectWords.length > 0 && (
        <div className="mb-8">
          <h2 className="text-heading-2 font-bold text-text-primary mb-4">
            📝 Yang Perlu Dipelajari Lagi
          </h2>
          <div className="space-y-3">
            {result.incorrectWords.map((item, index) => (
              <Card key={index}>
                <CardContent className="p-4">
                  <p className="text-body font-bold text-text-primary mb-2">
                    {item.question}
                  </p>
                  <div className="space-y-1">
                    <p className="text-body text-red-600">
                      <span className="font-medium">Jawabanmu:</span> {item.userAnswer}
                    </p>
                    <p className="text-body text-green-600">
                      <span className="font-medium">Jawaban benar:</span> {item.correctAnswer}
                    </p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}
      
      {/* Actions */}
      <div className="space-y-3">
        <Button
          onClick={handleUlangi}
          variant="accent"
          size="lg"
          fullWidth
        >
          🔄 Ulangi Kuis
        </Button>
        
        <Link href="/">
          <Button variant="secondary" size="lg" fullWidth>
            🏠 Kembali ke Beranda
          </Button>
        </Link>
      </div>
    </div>
  )
}
