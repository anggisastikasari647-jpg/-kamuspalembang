'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { ProgressBar } from '@/components/siswa/ProgressBar'
import { EmptyState } from '@/components/ui/EmptyState'
import { shuffle } from '@/lib/utils/shuffle'
import type { QuizQuestionWithOptions, QuizOption } from '@/types'

/**
 * Halaman Kuis Interaktif
 * Menampilkan 5 soal acak dengan feedback langsung
 */
export default function KuisPage() {
  const router = useRouter()
  const [questions, setQuestions] = useState<QuizQuestionWithOptions[]>([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [selectedOption, setSelectedOption] = useState<string | null>(null)
  const [hasAnswered, setHasAnswered] = useState(false)
  const [correctAnswers, setCorrectAnswers] = useState(0)
  const [incorrectAnswers, setIncorrectAnswers] = useState<Array<{
    question: string
    userAnswer: string
    correctAnswer: string
  }>>([])
  const [shuffledOptions, setShuffledOptions] = useState<QuizOption[]>([])
  const [isLoading, setIsLoading] = useState(true)
  
  // Fetch questions saat mount
  useEffect(() => {
    fetch('/api/quiz/random?limit=5')
      .then(res => res.json())
      .then(data => {
        setQuestions(data)
        setIsLoading(false)
      })
      .catch(err => {
        console.error('Error fetching questions:', err)
        setIsLoading(false)
      })
  }, [])
  
  // Shuffle options setiap kali soal berganti
  useEffect(() => {
    if (questions.length > 0 && currentIndex < questions.length) {
      const currentQuestion = questions[currentIndex]
      setShuffledOptions(shuffle(currentQuestion.options))
    }
  }, [currentIndex, questions])
  
  if (isLoading) {
    return (
      <div className="container-mobile py-6">
        <div className="text-center">
          <div className="text-6xl mb-4">⏳</div>
          <p className="text-body-large text-text-secondary">Memuat soal...</p>
        </div>
      </div>
    )
  }
  
  if (questions.length === 0) {
    return (
      <div className="container-mobile py-6">
        <EmptyState
          title="Belum Ada Soal"
          description="Belum ada soal kuis tersedia. Hubungi guru untuk menambahkan soal."
          icon="📝"
        />
        <Button
          onClick={() => router.push('/')}
          className="mt-6"
          fullWidth
        >
          Kembali ke Beranda
        </Button>
      </div>
    )
  }
  
  const currentQuestion = questions[currentIndex]
  const correctOption = shuffledOptions.find(opt => opt.is_correct)
  
  const handleSelectOption = (optionId: string) => {
    if (hasAnswered) return
    setSelectedOption(optionId)
  }
  
  const handleSubmitAnswer = () => {
    if (!selectedOption) return
    
    setHasAnswered(true)
    
    const selected = shuffledOptions.find(opt => opt.id === selectedOption)
    
    if (selected?.is_correct) {
      setCorrectAnswers(prev => prev + 1)
    } else {
      setIncorrectAnswers(prev => [
        ...prev,
        {
          question: currentQuestion.question,
          userAnswer: selected?.option_text || '',
          correctAnswer: correctOption?.option_text || '',
        },
      ])
    }
  }
  
  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      // Next question
      setCurrentIndex(prev => prev + 1)
      setSelectedOption(null)
      setHasAnswered(false)
    } else {
      // Finish quiz
      const result = {
        totalQuestions: questions.length,
        correctAnswers,
        incorrectWords: incorrectAnswers,
      }
      
      // Simpan hasil di sessionStorage
      sessionStorage.setItem('quizResult', JSON.stringify(result))
      router.push('/kuis/hasil')
    }
  }
  
  const isCorrect = hasAnswered && shuffledOptions.find(opt => opt.id === selectedOption)?.is_correct
  
  return (
    <div className="container-mobile py-6">
      {/* Header */}
      <header className="mb-6">
        <h1 className="text-heading-1 font-extrabold text-primary mb-4">
          🎯 Kuis
        </h1>
        <ProgressBar current={currentIndex + 1} total={questions.length} />
      </header>
      
      {/* Question */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <h2 className="text-heading-2 font-bold text-text-primary mb-6">
            {currentQuestion.question}
          </h2>
          
          {/* Options */}
          <div className="space-y-3">
            {shuffledOptions.map((option, index) => {
              const isSelected = selectedOption === option.id
              const showCorrect = hasAnswered && option.is_correct
              const showWrong = hasAnswered && isSelected && !option.is_correct
              
              return (
                <button
                  key={option.id}
                  onClick={() => handleSelectOption(option.id)}
                  disabled={hasAnswered}
                  className={`w-full p-4 rounded-button border-2 text-left transition-all ${
                    showCorrect
                      ? 'bg-green-100 border-green-500 text-green-900'
                      : showWrong
                      ? 'bg-red-100 border-red-500 text-red-900'
                      : isSelected
                      ? 'bg-primary/10 border-primary'
                      : 'bg-background-surface border-border hover:border-primary'
                  } disabled:cursor-not-allowed`}
                >
                  <div className="flex items-start gap-3">
                    <span className="font-bold text-body-large">
                      {String.fromCharCode(65 + index)}.
                    </span>
                    <span className="text-body-large flex-1">
                      {option.option_text}
                    </span>
                    {showCorrect && <span className="text-2xl">✓</span>}
                    {showWrong && <span className="text-2xl">✗</span>}
                  </div>
                </button>
              )
            })}
          </div>
          
          {/* Feedback */}
          {hasAnswered && (
            <div className={`mt-6 p-4 rounded-button ${
              isCorrect ? 'bg-green-100 text-green-900' : 'bg-red-100 text-red-900'
            }`}>
              <p className="text-body-large font-bold">
                {isCorrect ? '🎉 Benar! Hebat!' : '😔 Kurang Tepat'}
              </p>
              {!isCorrect && (
                <p className="text-body mt-1">
                  Jawaban yang benar: <strong>{correctOption?.option_text}</strong>
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Actions */}
      <div className="space-y-3">
        {!hasAnswered ? (
          <Button
            onClick={handleSubmitAnswer}
            disabled={!selectedOption}
            size="lg"
            fullWidth
          >
            Jawab
          </Button>
        ) : (
          <Button
            onClick={handleNext}
            variant="accent"
            size="lg"
            fullWidth
          >
            {currentIndex < questions.length - 1 ? 'Lanjut' : 'Lihat Hasil'}
          </Button>
        )}
      </div>
    </div>
  )
}
