import type { Metadata } from 'next'
import { Nunito } from 'next/font/google'
import './globals.css'

// Font Nunito untuk UI yang ramah anak
const nunito = Nunito({
  subsets: ['latin'],
  weight: ['400', '500', '600', '700', '800'],
  variable: '--font-nunito',
  display: 'swap',
})

export const metadata: Metadata = {
  title: 'Belajar Baso Pelembang',
  description: 'Media Pembelajaran Interaktif Bahasa Palembang untuk Siswa Kelas III SD Negeri 182 Palembang',
  viewport: 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no',
  themeColor: '#8E1B2B',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="id" className={nunito.variable}>
      <body>{children}</body>
    </html>
  )
}
