import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Design tokens untuk tema Media Pembelajaran Bahasa Palembang
        primary: {
          DEFAULT: '#8E1B2B', // Merah songket
          dark: '#6B1420',
          light: '#A82338',
        },
        accent: {
          DEFAULT: '#F2B33D', // Emas
          dark: '#D99C2A',
          light: '#F5C563',
        },
        background: {
          DEFAULT: '#FFF8EA', // Krem
          surface: '#FFFFFF',
        },
        text: {
          primary: '#2B1A12',
          secondary: '#6B5646',
          onPrimary: '#FFFFFF',
          onAccent: '#2B1A12',
        },
        border: {
          DEFAULT: '#E8D5B0',
        },
      },
      borderRadius: {
        card: '20px',
        button: '16px',
      },
      fontFamily: {
        sans: ['var(--font-nunito)', 'system-ui', 'sans-serif'],
      },
      fontSize: {
        // Ukuran font yang sesuai untuk anak kelas III SD
        'heading-1': ['2rem', { lineHeight: '2.5rem', fontWeight: '800' }],
        'heading-2': ['1.5rem', { lineHeight: '2rem', fontWeight: '700' }],
        'heading-3': ['1.25rem', { lineHeight: '1.75rem', fontWeight: '700' }],
        body: ['1rem', { lineHeight: '1.5rem', fontWeight: '500' }],
        'body-large': ['1.125rem', { lineHeight: '1.75rem', fontWeight: '500' }],
        caption: ['0.875rem', { lineHeight: '1.25rem', fontWeight: '500' }],
      },
      minHeight: {
        touch: '48px', // Minimal target sentuh untuk anak-anak
      },
      minWidth: {
        touch: '48px',
      },
    },
  },
  plugins: [],
}
export default config
