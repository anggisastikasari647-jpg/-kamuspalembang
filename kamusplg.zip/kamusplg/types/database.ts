/**
 * Tipe TypeScript yang dihasilkan dari skema database Supabase
 * File ini akan diupdate setelah migrasi database dibuat
 */

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      categories: {
        Row: {
          id: string
          name: string
          slug: string
          sort_order: number
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          sort_order?: number
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          sort_order?: number
          created_at?: string
        }
      }
      words: {
        Row: {
          id: string
          palembang: string
          indonesia: string
          category_id: string
          example_palembang: string | null
          example_indonesia: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          palembang: string
          indonesia: string
          category_id: string
          example_palembang?: string | null
          example_indonesia?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          palembang?: string
          indonesia?: string
          category_id?: string
          example_palembang?: string | null
          example_indonesia?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      quiz_questions: {
        Row: {
          id: string
          question: string
          category_id: string | null
          created_at: string
        }
        Insert: {
          id?: string
          question: string
          category_id?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          question?: string
          category_id?: string | null
          created_at?: string
        }
      }
      quiz_options: {
        Row: {
          id: string
          question_id: string
          option_text: string
          is_correct: boolean
        }
        Insert: {
          id?: string
          question_id: string
          option_text: string
          is_correct?: boolean
        }
        Update: {
          id?: string
          question_id?: string
          option_text?: string
          is_correct?: boolean
        }
      }
      profiles: {
        Row: {
          id: string
          role: string
        }
        Insert: {
          id: string
          role?: string
        }
        Update: {
          id?: string
          role?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      is_staff: {
        Args: Record<PropertyKey, never>
        Returns: boolean
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}
