import type { Database } from './database'

// Tipe untuk tabel-tabel database
export type Category = Database['public']['Tables']['categories']['Row']
export type Word = Database['public']['Tables']['words']['Row']
export type QuizQuestion = Database['public']['Tables']['quiz_questions']['Row']
export type QuizOption = Database['public']['Tables']['quiz_options']['Row']
export type Profile = Database['public']['Tables']['profiles']['Row']

// Tipe untuk insert operations
export type CategoryInsert = Database['public']['Tables']['categories']['Insert']
export type WordInsert = Database['public']['Tables']['words']['Insert']
export type QuizQuestionInsert = Database['public']['Tables']['quiz_questions']['Insert']
export type QuizOptionInsert = Database['public']['Tables']['quiz_options']['Insert']

// Tipe untuk update operations
export type CategoryUpdate = Database['public']['Tables']['categories']['Update']
export type WordUpdate = Database['public']['Tables']['words']['Update']
export type QuizQuestionUpdate = Database['public']['Tables']['quiz_questions']['Update']
export type QuizOptionUpdate = Database['public']['Tables']['quiz_options']['Update']

// Tipe gabungan untuk Word dengan Category
export type WordWithCategory = Word & {
  category: Category
}

// Tipe gabungan untuk QuizQuestion dengan Options
export type QuizQuestionWithOptions = QuizQuestion & {
  options: QuizOption[]
}

// Tipe untuk hasil kuis (hanya di client, tidak disimpan ke database)
export type QuizResult = {
  totalQuestions: number
  correctAnswers: number
  incorrectWords: Array<{
    question: string
    userAnswer: string
    correctAnswer: string
  }>
}
