import { type NextRequest } from 'next/server'
import { updateSession } from '@/lib/supabase/middleware'

/**
 * Middleware untuk proteksi rute admin
 * - Semua rute /admin/* kecuali /admin/login memerlukan autentikasi
 * - User yang belum login akan diarahkan ke /admin/login
 * - User yang sudah login tidak bisa mengakses /admin/login (redirect ke /admin/kosakata)
 */
export async function middleware(request: NextRequest) {
  const { supabaseResponse, user } = await updateSession(request)
  
  const path = request.nextUrl.pathname
  
  // Proteksi rute admin
  if (path.startsWith('/admin')) {
    const isLoginPage = path === '/admin/login'
    const isAuthenticated = !!user
    
    // Jika belum login dan bukan di halaman login, redirect ke login
    if (!isAuthenticated && !isLoginPage) {
      const url = request.nextUrl.clone()
      url.pathname = '/admin/login'
      return NextResponse.redirect(url)
    }
    
    // Jika sudah login tapi mengakses halaman login, redirect ke dashboard
    if (isAuthenticated && isLoginPage) {
      const url = request.nextUrl.clone()
      url.pathname = '/admin/kosakata'
      return NextResponse.redirect(url)
    }
  }

  return supabaseResponse
}

export const config = {
  matcher: [
    /*
     * Match semua request paths kecuali:
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     * - public folder
     */
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)',
  ],
}
