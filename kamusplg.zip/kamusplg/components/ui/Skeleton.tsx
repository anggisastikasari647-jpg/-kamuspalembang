import { HTMLAttributes } from 'react'
import { cn } from '@/lib/utils/cn'

/**
 * Komponen Skeleton untuk loading state
 * Memberikan feedback visual saat data sedang dimuat
 */
export function Skeleton({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn('animate-pulse rounded-button bg-border', className)}
      {...props}
    />
  )
}

// Skeleton untuk Card
export function CardSkeleton() {
  return (
    <div className="card-elevated p-4 space-y-3">
      <Skeleton className="h-6 w-3/4" />
      <Skeleton className="h-4 w-full" />
      <Skeleton className="h-4 w-5/6" />
    </div>
  )
}

// Skeleton untuk Word Card
export function WordCardSkeleton() {
  return (
    <div className="card-elevated p-4 space-y-2">
      <Skeleton className="h-8 w-2/3" />
      <Skeleton className="h-5 w-1/2" />
    </div>
  )
}

// Skeleton untuk Category Card
export function CategoryCardSkeleton() {
  return (
    <div className="card-elevated p-6 space-y-2">
      <Skeleton className="h-10 w-10 rounded-full" />
      <Skeleton className="h-6 w-full" />
      <Skeleton className="h-4 w-2/3" />
    </div>
  )
}
