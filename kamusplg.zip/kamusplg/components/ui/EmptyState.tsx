import { HTMLAttributes } from 'react'
import { cn } from '@/lib/utils/cn'

export interface EmptyStateProps extends HTMLAttributes<HTMLDivElement> {
  title: string
  description?: string
  icon?: string
}

/**
 * Komponen untuk menampilkan state ketika data kosong
 * Dengan pesan yang ramah untuk anak-anak
 */
export function EmptyState({ title, description, icon = '🔍', className, ...props }: EmptyStateProps) {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center py-12 px-4 text-center',
        className
      )}
      {...props}
    >
      <div className="text-6xl mb-4">{icon}</div>
      <h3 className="text-heading-3 font-bold text-text-primary mb-2">
        {title}
      </h3>
      {description && (
        <p className="text-body text-text-secondary max-w-md">
          {description}
        </p>
      )}
    </div>
  )
}
