import { ButtonHTMLAttributes, forwardRef } from 'react'
import { cn } from '@/lib/utils/cn'

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'accent' | 'outline' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  fullWidth?: boolean
}

/**
 * Komponen Button dengan styling konsisten
 * Semua tombol memenuhi ukuran minimum sentuh (48px) untuk anak-anak
 */
const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = 'primary', size = 'md', fullWidth = false, disabled, children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        disabled={disabled}
        className={cn(
          // Base styles
          'inline-flex items-center justify-center rounded-button font-bold',
          'transition-all duration-200 active:scale-95',
          'disabled:opacity-50 disabled:cursor-not-allowed disabled:active:scale-100',
          'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2',
          
          // Ukuran minimum sentuh
          'min-h-touch',
          
          // Variants
          {
            'bg-primary text-text-onPrimary hover:bg-primary-dark shadow-md': variant === 'primary',
            'bg-background-surface text-text-primary border-2 border-border hover:bg-border': variant === 'secondary',
            'bg-accent text-text-onAccent hover:bg-accent-dark shadow-md': variant === 'accent',
            'border-2 border-primary text-primary hover:bg-primary hover:text-text-onPrimary': variant === 'outline',
            'text-primary hover:bg-primary/10': variant === 'ghost',
          },
          
          // Sizes
          {
            'px-4 py-2 text-sm': size === 'sm',
            'px-6 py-3 text-body': size === 'md',
            'px-8 py-4 text-body-large': size === 'lg',
          },
          
          // Full width
          fullWidth && 'w-full',
          
          className
        )}
        {...props}
      >
        {children}
      </button>
    )
  }
)

Button.displayName = 'Button'

export { Button }
