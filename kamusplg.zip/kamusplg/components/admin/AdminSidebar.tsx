'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils/cn'

/**
 * Sidebar navigasi untuk admin panel
 */
export function AdminSidebar() {
  const pathname = usePathname()
  
  const menuItems = [
    {
      href: '/admin/kosakata',
      label: 'Kosakata',
      icon: '📚',
    },
    {
      href: '/admin/kategori',
      label: 'Kategori',
      icon: '🏷️',
    },
    {
      href: '/admin/soal',
      label: 'Soal Kuis',
      icon: '❓',
    },
  ]
  
  return (
    <aside className="w-64 bg-primary min-h-screen p-4 text-text-onPrimary">
      {/* Logo/Title */}
      <div className="mb-8">
        <h1 className="text-heading-2 font-bold">
          Panel Admin
        </h1>
        <p className="text-caption opacity-80">
          Media Pembelajaran
        </p>
      </div>
      
      {/* Menu */}
      <nav className="space-y-2">
        {menuItems.map((item) => {
          const isActive = pathname.startsWith(item.href)
          
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-4 py-3 rounded-button transition-colors',
                isActive
                  ? 'bg-accent text-text-onAccent font-bold'
                  : 'hover:bg-primary-dark'
              )}
            >
              <span className="text-2xl">{item.icon}</span>
              <span className="text-body">{item.label}</span>
            </Link>
          )
        })}
      </nav>
    </aside>
  )
}
