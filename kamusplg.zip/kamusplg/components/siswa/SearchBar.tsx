'use client'

import { useState, useEffect } from 'react'
import { Input } from '@/components/ui/Input'

interface SearchBarProps {
  onSearch: (query: string) => void
  placeholder?: string
  debounceMs?: number
}

/**
 * Search bar dengan debounce untuk pencarian real-time
 */
export function SearchBar({ 
  onSearch, 
  placeholder = 'Cari kata...', 
  debounceMs = 300 
}: SearchBarProps) {
  const [query, setQuery] = useState('')
  
  // Debounce search
  useEffect(() => {
    const timer = setTimeout(() => {
      onSearch(query)
    }, debounceMs)
    
    return () => clearTimeout(timer)
  }, [query, debounceMs, onSearch])
  
  return (
    <div className="relative">
      <Input
        type="search"
        placeholder={placeholder}
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="pr-10"
      />
      <div className="absolute right-3 top-1/2 -translate-y-1/2 text-2xl pointer-events-none">
        🔍
      </div>
    </div>
  )
}
