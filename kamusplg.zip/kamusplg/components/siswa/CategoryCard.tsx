import Link from 'next/link'
import { Card } from '@/components/ui/Card'
import type { Category } from '@/types'

interface CategoryCardProps {
  category: Category
  wordCount?: number
}

/**
 * Kartu kategori untuk ditampilkan di beranda
 * Menampilkan icon, nama kategori, dan jumlah kata
 */
export function CategoryCard({ category, wordCount = 0 }: CategoryCardProps) {
  // Icon emoji untuk setiap kategori
  const categoryIcons: Record<string, string> = {
    'sehari-hari': '🌞',
    'keluarga': '👨‍👩‍👧‍👦',
    'hewan': '🐾',
    'makanan': '🍽️',
  }
  
  const icon = categoryIcons[category.slug] || '📚'
  
  return (
    <Link href={`/kamus/${category.slug}`}>
      <Card className="hover:shadow-lg hover:scale-105 transition-all duration-200 cursor-pointer h-full">
        <div className="flex flex-col items-center text-center p-2">
          <div className="text-5xl mb-3">{icon}</div>
          <h3 className="text-heading-3 font-bold text-primary mb-1">
            {category.name}
          </h3>
          <p className="text-caption text-text-secondary">
            {wordCount} kata
          </p>
        </div>
      </Card>
    </Link>
  )
}
