interface ProgressBarProps {
  current: number
  total: number
}

/**
 * Progress bar untuk menampilkan progres kuis
 */
export function ProgressBar({ current, total }: ProgressBarProps) {
  const percentage = (current / total) * 100
  
  return (
    <div className="w-full">
      {/* Text indicator */}
      <div className="flex justify-between items-center mb-2">
        <span className="text-body font-bold text-text-primary">
          Soal {current} dari {total}
        </span>
        <span className="text-body font-bold text-accent">
          {Math.round(percentage)}%
        </span>
      </div>
      
      {/* Progress bar */}
      <div className="w-full h-3 bg-border rounded-full overflow-hidden">
        <div
          className="h-full bg-accent transition-all duration-300 ease-out"
          style={{ width: `${percentage}%` }}
        />
      </div>
    </div>
  )
}
