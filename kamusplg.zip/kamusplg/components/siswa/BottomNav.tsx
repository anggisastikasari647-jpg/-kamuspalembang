'use client'

import Link from 'next/link'
import { usePathname } from 'next/navigation'
import { cn } from '@/lib/utils/cn'

/**
 * Bottom Navigation untuk siswa
 * Sticky di bawah dengan 3 menu: Beranda, Kamus, Kuis
 */
export function BottomNav() {
  const pathname = usePathname()
  
  const navItems = [
    {
      href: '/',
      label: 'Beranda',
      icon: '🏠',
      isActive: pathname === '/',
    },
    {
      href: '/kamus',
      label: 'Kamus',
      icon: '📖',
      isActive: pathname.startsWith('/kamus'),
    },
    {
      href: '/kuis',
      label: 'Kuis',
      icon: '🎯',
      isActive: pathname.startsWith('/kuis'),
    },
  ]
  
  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-background-surface border-t-2 border-border shadow-lg z-40">
      <div className="container-mobile">
        <div className="flex items-center justify-around py-2">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex flex-col items-center justify-center min-w-touch min-h-touch rounded-button transition-colors',
                item.isActive
                  ? 'text-primary font-bold'
                  : 'text-text-secondary hover:text-primary'
              )}
            >
              <span className="text-2xl mb-1">{item.icon}</span>
              <span className="text-caption">{item.label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  )
}
