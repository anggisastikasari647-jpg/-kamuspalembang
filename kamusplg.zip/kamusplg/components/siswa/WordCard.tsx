'use client'

import { useState } from 'react'
import { Card, CardContent } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import type { WordWithCategory } from '@/types'

interface WordCardProps {
  word: WordWithCategory
}

/**
 * Kartu kata untuk ditampilkan di halaman kamus
 * Dengan tombol toggle untuk menampilkan contoh kalimat
 */
export function WordCard({ word }: WordCardProps) {
  const [showExample, setShowExample] = useState(false)
  
  const hasExample = word.example_palembang && word.example_indonesia
  
  return (
    <Card>
      <CardContent className="p-4">
        {/* Kata Palembang */}
        <h3 className="text-heading-2 font-bold text-primary mb-2">
          {word.palembang}
        </h3>
        
        {/* Arti Indonesia */}
        <p className="text-body-large text-text-primary mb-3">
          {word.indonesia}
        </p>
        
        {/* Badge Kategori */}
        <div className="inline-block px-3 py-1 bg-accent/20 text-accent-dark rounded-full text-caption font-medium mb-3">
          {word.category.name}
        </div>
        
        {/* Tombol Contoh */}
        {hasExample && (
          <>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowExample(!showExample)}
              className="w-full mt-2"
            >
              {showExample ? '▲ Sembunyikan Contoh' : '▼ Lihat Contoh'}
            </Button>
            
            {/* Contoh Kalimat */}
            {showExample && (
              <div className="mt-3 p-3 bg-background rounded-button border border-border">
                <p className="text-body text-primary font-medium mb-1">
                  "{word.example_palembang}"
                </p>
                <p className="text-body text-text-secondary italic">
                  "{word.example_indonesia}"
                </p>
              </div>
            )}
          </>
        )}
      </CardContent>
    </Card>
  )
}
