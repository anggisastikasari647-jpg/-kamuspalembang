interface ScoreCircleProps {
  correct: number
  total: number
}

/**
 * Lingkaran skor untuk hasil kuis
 * Menampilkan skor dalam bentuk visual yang menarik
 */
export function ScoreCircle({ correct, total }: ScoreCircleProps) {
  const percentage = (correct / total) * 100
  const circumference = 2 * Math.PI * 80 // radius 80
  const strokeDashoffset = circumference - (percentage / 100) * circumference
  
  // Warna berdasarkan persentase
  let color = '#8E1B2B' // primary (merah)
  if (percentage >= 80) {
    color = '#10B981' // hijau
  } else if (percentage >= 60) {
    color = '#F2B33D' // accent (emas)
  }
  
  return (
    <div className="relative w-48 h-48 mx-auto">
      {/* SVG Circle */}
      <svg className="transform -rotate-90 w-full h-full">
        {/* Background circle */}
        <circle
          cx="96"
          cy="96"
          r="80"
          stroke="#E8D5B0"
          strokeWidth="12"
          fill="none"
        />
        {/* Progress circle */}
        <circle
          cx="96"
          cy="96"
          r="80"
          stroke={color}
          strokeWidth="12"
          fill="none"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-1000 ease-out"
        />
      </svg>
      
      {/* Score text */}
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <div className="text-5xl font-extrabold text-primary mb-1">
          {correct}/{total}
        </div>
        <div className="text-heading-3 font-bold text-text-secondary">
          {Math.round(percentage)}%
        </div>
      </div>
    </div>
  )
}
