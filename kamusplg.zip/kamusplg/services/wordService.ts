import { createClient } from '@/lib/supabase/server'
import type { Word, WordWithCategory, WordInsert, WordUpdate } from '@/types'

/**
 * Service untuk operasi CRUD kosakata
 * Semua fungsi berjalan di server-side
 */

/**
 * Mengambil semua kata dengan informasi kategori
 */
export async function getAllWords(): Promise<WordWithCategory[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('words')
    .select(`
      *,
      category:categories(*)
    `)
    .order('created_at', { ascending: false })
  
  if (error) {
    console.error('Error fetching words:', error)
    throw new Error('Gagal mengambil data kosakata')
  }
  
  return data as WordWithCategory[]
}

/**
 * Mengambil kata berdasarkan kategori
 */
export async function getWordsByCategory(categoryId: string): Promise<WordWithCategory[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('words')
    .select(`
      *,
      category:categories(*)
    `)
    .eq('category_id', categoryId)
    .order('palembang', { ascending: true })
  
  if (error) {
    console.error('Error fetching words by category:', error)
    throw new Error('Gagal mengambil data kosakata')
  }
  
  return data as WordWithCategory[]
}

/**
 * Mencari kata berdasarkan query
 * Mencari di kolom palembang dan indonesia
 */
export async function searchWords(query: string): Promise<WordWithCategory[]> {
  const supabase = await createClient()
  
  // Menggunakan ilike untuk pencarian case-insensitive
  const { data, error } = await supabase
    .from('words')
    .select(`
      *,
      category:categories(*)
    `)
    .or(`palembang.ilike.%${query}%,indonesia.ilike.%${query}%`)
    .order('palembang', { ascending: true })
  
  if (error) {
    console.error('Error searching words:', error)
    throw new Error('Gagal mencari kosakata')
  }
  
  return data as WordWithCategory[]
}

/**
 * Mencari kata dengan filter kategori
 */
export async function searchWordsWithCategory(
  query: string,
  categoryId?: string
): Promise<WordWithCategory[]> {
  const supabase = await createClient()
  
  let queryBuilder = supabase
    .from('words')
    .select(`
      *,
      category:categories(*)
    `)
  
  // Filter by category jika ada
  if (categoryId) {
    queryBuilder = queryBuilder.eq('category_id', categoryId)
  }
  
  // Filter by search query
  if (query) {
    queryBuilder = queryBuilder.or(`palembang.ilike.%${query}%,indonesia.ilike.%${query}%`)
  }
  
  const { data, error } = await queryBuilder.order('palembang', { ascending: true })
  
  if (error) {
    console.error('Error searching words:', error)
    throw new Error('Gagal mencari kosakata')
  }
  
  return data as WordWithCategory[]
}

/**
 * Mengambil kata berdasarkan ID
 */
export async function getWordById(id: string): Promise<WordWithCategory | null> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('words')
    .select(`
      *,
      category:categories(*)
    `)
    .eq('id', id)
    .single()
  
  if (error) {
    if (error.code === 'PGRST116') {
      return null
    }
    console.error('Error fetching word:', error)
    throw new Error('Gagal mengambil data kosakata')
  }
  
  return data as WordWithCategory
}

/**
 * Membuat kata baru
 */
export async function createWord(word: WordInsert): Promise<Word> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('words')
    .insert(word)
    .select()
    .single()
  
  if (error) {
    console.error('Error creating word:', error)
    throw new Error('Gagal membuat kosakata')
  }
  
  return data
}

/**
 * Mengupdate kata
 */
export async function updateWord(id: string, updates: WordUpdate): Promise<Word> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('words')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  
  if (error) {
    console.error('Error updating word:', error)
    throw new Error('Gagal mengupdate kosakata')
  }
  
  return data
}

/**
 * Menghapus kata
 */
export async function deleteWord(id: string): Promise<void> {
  const supabase = await createClient()
  
  const { error } = await supabase
    .from('words')
    .delete()
    .eq('id', id)
  
  if (error) {
    console.error('Error deleting word:', error)
    throw new Error('Gagal menghapus kosakata')
  }
}
