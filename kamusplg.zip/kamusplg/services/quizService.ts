import { createClient } from '@/lib/supabase/server'
import type { QuizQuestionWithOptions, QuizQuestionInsert, QuizOptionInsert } from '@/types'

/**
 * Service untuk operasi CRUD soal kuis
 * Semua fungsi berjalan di server-side
 */

/**
 * Mengambil semua soal kuis dengan opsi jawaban
 */
export async function getAllQuestions(): Promise<QuizQuestionWithOptions[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('quiz_questions')
    .select(`
      *,
      options:quiz_options(*),
      category:categories(*)
    `)
    .order('created_at', { ascending: false })
  
  if (error) {
    console.error('Error fetching questions:', error)
    throw new Error('Gagal mengambil data soal')
  }
  
  return data as QuizQuestionWithOptions[]
}

/**
 * Mengambil soal acak untuk kuis
 * @param limit Jumlah soal yang diambil (default 5)
 */
export async function getRandomQuestions(limit: number = 5): Promise<QuizQuestionWithOptions[]> {
  const supabase = await createClient()
  
  // Ambil semua soal dulu
  const { data, error } = await supabase
    .from('quiz_questions')
    .select(`
      *,
      options:quiz_options(*)
    `)
  
  if (error) {
    console.error('Error fetching questions:', error)
    throw new Error('Gagal mengambil soal kuis')
  }
  
  if (!data || data.length === 0) {
    return []
  }
  
  // Acak dan ambil sejumlah limit
  const shuffled = data.sort(() => Math.random() - 0.5)
  return shuffled.slice(0, Math.min(limit, data.length)) as QuizQuestionWithOptions[]
}

/**
 * Mengambil soal berdasarkan ID
 */
export async function getQuestionById(id: string): Promise<QuizQuestionWithOptions | null> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('quiz_questions')
    .select(`
      *,
      options:quiz_options(*),
      category:categories(*)
    `)
    .eq('id', id)
    .single()
  
  if (error) {
    if (error.code === 'PGRST116') {
      return null
    }
    console.error('Error fetching question:', error)
    throw new Error('Gagal mengambil data soal')
  }
  
  return data as QuizQuestionWithOptions
}

/**
 * Membuat soal baru beserta opsi jawaban
 */
export async function createQuestion(
  question: QuizQuestionInsert,
  options: Omit<QuizOptionInsert, 'question_id'>[]
): Promise<QuizQuestionWithOptions> {
  const supabase = await createClient()
  
  // Validasi: harus ada 4 opsi dan tepat 1 benar
  if (options.length !== 4) {
    throw new Error('Harus ada tepat 4 opsi jawaban')
  }
  
  const correctCount = options.filter(opt => opt.is_correct).length
  if (correctCount !== 1) {
    throw new Error('Harus ada tepat 1 jawaban yang benar')
  }
  
  // Insert question
  const { data: questionData, error: questionError } = await supabase
    .from('quiz_questions')
    .insert(question)
    .select()
    .single()
  
  if (questionError) {
    console.error('Error creating question:', questionError)
    throw new Error('Gagal membuat soal')
  }
  
  // Insert options
  const optionsWithQuestionId = options.map(opt => ({
    ...opt,
    question_id: questionData.id,
  }))
  
  const { data: optionsData, error: optionsError } = await supabase
    .from('quiz_options')
    .insert(optionsWithQuestionId)
    .select()
  
  if (optionsError) {
    // Rollback: hapus question jika gagal insert options
    await supabase.from('quiz_questions').delete().eq('id', questionData.id)
    console.error('Error creating options:', optionsError)
    throw new Error('Gagal membuat opsi jawaban')
  }
  
  return {
    ...questionData,
    options: optionsData,
  } as QuizQuestionWithOptions
}

/**
 * Mengupdate soal dan opsi jawaban
 */
export async function updateQuestion(
  id: string,
  question: Partial<QuizQuestionInsert>,
  options?: Omit<QuizOptionInsert, 'question_id'>[]
): Promise<QuizQuestionWithOptions> {
  const supabase = await createClient()
  
  // Update question
  const { data: questionData, error: questionError } = await supabase
    .from('quiz_questions')
    .update(question)
    .eq('id', id)
    .select()
    .single()
  
  if (questionError) {
    console.error('Error updating question:', questionError)
    throw new Error('Gagal mengupdate soal')
  }
  
  // Update options jika ada
  if (options) {
    // Validasi
    if (options.length !== 4) {
      throw new Error('Harus ada tepat 4 opsi jawaban')
    }
    
    const correctCount = options.filter(opt => opt.is_correct).length
    if (correctCount !== 1) {
      throw new Error('Harus ada tepat 1 jawaban yang benar')
    }
    
    // Hapus opsi lama
    await supabase.from('quiz_options').delete().eq('question_id', id)
    
    // Insert opsi baru
    const optionsWithQuestionId = options.map(opt => ({
      ...opt,
      question_id: id,
    }))
    
    const { data: optionsData, error: optionsError } = await supabase
      .from('quiz_options')
      .insert(optionsWithQuestionId)
      .select()
    
    if (optionsError) {
      console.error('Error updating options:', optionsError)
      throw new Error('Gagal mengupdate opsi jawaban')
    }
    
    return {
      ...questionData,
      options: optionsData,
    } as QuizQuestionWithOptions
  }
  
  // Jika tidak update options, ambil options yang ada
  const { data: existingOptions } = await supabase
    .from('quiz_options')
    .select('*')
    .eq('question_id', id)
  
  return {
    ...questionData,
    options: existingOptions || [],
  } as QuizQuestionWithOptions
}

/**
 * Menghapus soal (opsi jawaban akan ikut terhapus karena ON DELETE CASCADE)
 */
export async function deleteQuestion(id: string): Promise<void> {
  const supabase = await createClient()
  
  const { error } = await supabase
    .from('quiz_questions')
    .delete()
    .eq('id', id)
  
  if (error) {
    console.error('Error deleting question:', error)
    throw new Error('Gagal menghapus soal')
  }
}
