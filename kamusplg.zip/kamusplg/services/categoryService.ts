import { createClient } from '@/lib/supabase/server'
import type { Category, CategoryInsert, CategoryUpdate } from '@/types'

/**
 * Service untuk operasi CRUD kategori
 * Semua fungsi berjalan di server-side
 */

/**
 * Mengambil semua kategori, diurutkan berdasarkan sort_order
 */
export async function getAllCategories(): Promise<Category[]> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('sort_order', { ascending: true })
  
  if (error) {
    console.error('Error fetching categories:', error)
    throw new Error('Gagal mengambil data kategori')
  }
  
  return data || []
}

/**
 * Mengambil kategori berdasarkan slug
 */
export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .single()
  
  if (error) {
    if (error.code === 'PGRST116') {
      // Not found
      return null
    }
    console.error('Error fetching category:', error)
    throw new Error('Gagal mengambil data kategori')
  }
  
  return data
}

/**
 * Mengambil kategori berdasarkan ID
 */
export async function getCategoryById(id: string): Promise<Category | null> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('id', id)
    .single()
  
  if (error) {
    if (error.code === 'PGRST116') {
      return null
    }
    console.error('Error fetching category:', error)
    throw new Error('Gagal mengambil data kategori')
  }
  
  return data
}

/**
 * Menghitung jumlah kata per kategori
 */
export async function getCategoriesWithWordCount() {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('categories')
    .select(`
      *,
      words:words(count)
    `)
    .order('sort_order', { ascending: true })
  
  if (error) {
    console.error('Error fetching categories with count:', error)
    throw new Error('Gagal mengambil data kategori')
  }
  
  return data?.map(cat => ({
    ...cat,
    word_count: cat.words[0]?.count || 0,
  })) || []
}

/**
 * Membuat kategori baru
 */
export async function createCategory(category: CategoryInsert): Promise<Category> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('categories')
    .insert(category)
    .select()
    .single()
  
  if (error) {
    console.error('Error creating category:', error)
    if (error.code === '23505') {
      throw new Error('Nama atau slug kategori sudah digunakan')
    }
    throw new Error('Gagal membuat kategori')
  }
  
  return data
}

/**
 * Mengupdate kategori
 */
export async function updateCategory(id: string, updates: CategoryUpdate): Promise<Category> {
  const supabase = await createClient()
  
  const { data, error } = await supabase
    .from('categories')
    .update(updates)
    .eq('id', id)
    .select()
    .single()
  
  if (error) {
    console.error('Error updating category:', error)
    if (error.code === '23505') {
      throw new Error('Nama atau slug kategori sudah digunakan')
    }
    throw new Error('Gagal mengupdate kategori')
  }
  
  return data
}

/**
 * Menghapus kategori
 * Akan gagal jika masih ada kata yang terkait (foreign key constraint)
 */
export async function deleteCategory(id: string): Promise<void> {
  const supabase = await createClient()
  
  const { error } = await supabase
    .from('categories')
    .delete()
    .eq('id', id)
  
  if (error) {
    console.error('Error deleting category:', error)
    if (error.code === '23503') {
      throw new Error('Tidak dapat menghapus kategori yang masih memiliki kata. Hapus kata terkait terlebih dahulu.')
    }
    throw new Error('Gagal menghapus kategori')
  }
}
