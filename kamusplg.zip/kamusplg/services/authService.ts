import { createClient } from '@/lib/supabase/server'

/**
 * Service untuk autentikasi guru/admin
 */

/**
 * Memeriksa apakah user saat ini terautentikasi dan memiliki akses staff
 */
export async function getCurrentUser() {
  const supabase = await createClient()
  
  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()
  
  if (error || !user) {
    return null
  }
  
  // Cek apakah user ada di tabel profiles
  const { data: profile } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', user.id)
    .single()
  
  if (!profile) {
    return null
  }
  
  return {
    ...user,
    role: profile.role,
  }
}

/**
 * Memeriksa apakah user saat ini adalah staff
 */
export async function isStaff(): Promise<boolean> {
  const user = await getCurrentUser()
  return user !== null
}

/**
 * Sign out user
 */
export async function signOut() {
  const supabase = await createClient()
  const { error } = await supabase.auth.signOut()
  
  if (error) {
    throw new Error('Gagal keluar dari akun')
  }
}
