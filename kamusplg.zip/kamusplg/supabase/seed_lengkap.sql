-- Seed Data Lengkap untuk Testing
-- Media Pembelajaran Bahasa Palembang

-- ========================================
-- 1. INSERT KATEGORI
-- ========================================
INSERT INTO categories (name, slug, sort_order) VALUES
  ('Sehari-hari', 'sehari-hari', 1),
  ('Keluarga', 'keluarga', 2),
  ('Hewan', 'hewan', 3),
  ('Makanan', 'makanan', 4);

-- ========================================
-- 2. INSERT KOSAKATA SEHARI-HARI
-- ========================================
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'nian', 'sangat', id, 'Panas nian ari ini', 'Sangat panas hari ini'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'gale', 'semua', id, 'Gale wong dak mandi', 'Semua orang sudah mandi'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'kemane', 'kemana', id, 'Kau ngape kemane?', 'Kamu mau pergi kemana?'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'ngape', 'mau/akan', id, 'Aku ngape pergi ke sekolah', 'Aku akan pergi ke sekolah'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'dak', 'sudah', id, 'Aku dak makan', 'Aku sudah makan'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'due', 'dua', id, 'Aku ade due ekor kucing', 'Aku punya dua ekor kucing'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'tige', 'tiga', id, 'Aku beli tige buah mangga', 'Aku beli tiga buah mangga'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'empak', 'empat', id, 'Rumahku ade empak kamar', 'Rumahku ada empat kamar'
FROM categories WHERE slug = 'sehari-hari';

-- ========================================
-- 3. INSERT KOSAKATA KELUARGA
-- ========================================
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'ayah', 'ayah', id, 'Ayah kerje di kanto', 'Ayah bekerja di kantor'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'mak', 'ibu', id, 'Mak masak di dapu', 'Ibu memasak di dapur'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'kakak', 'kakak', id, 'Kakak sekolah di SMP', 'Kakak sekolah di SMP'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'adik', 'adik', id, 'Adikku umurnye lime taun', 'Adikku umurnya lima tahun'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'embah', 'nenek', id, 'Embah lagi tidok', 'Nenek sedang tidur'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'aki', 'kakek', id, 'Aki suke baco koran', 'Kakek suka baca koran'
FROM categories WHERE slug = 'keluarga';

-- ========================================
-- 4. INSERT KOSAKATA HEWAN
-- ========================================
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'kucing', 'kucing', id, 'Kucing ni lucu nian', 'Kucing ini sangat lucu'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'asu', 'anjing', id, 'Asu kesayanganku ilang', 'Anjing kesayanganku hilang'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'manok', 'ayam', id, 'Manok beranak banyak', 'Ayam bertelur banyak'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'bebek', 'bebek', id, 'Bebek berenang di kolam', 'Bebek berenang di kolam'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'burung', 'burung', id, 'Burung terbang tinggi', 'Burung terbang tinggi'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'ikan', 'ikan', id, 'Ikan mas berenang di sungai', 'Ikan mas berenang di sungai'
FROM categories WHERE slug = 'hewan';

-- ========================================
-- 5. INSERT KOSAKATA MAKANAN
-- ========================================
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'pempek', 'pempek', id, 'Aku suke pempek kapal selam', 'Aku suka pempek kapal selam'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'cuko', 'saus pempek', id, 'Cuko ni pedes nian', 'Saus ini sangat pedas'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'kemplang', 'kerupuk kemplang', id, 'Kemplang enak dimakan samo cuko', 'Kemplang enak dimakan dengan cuko'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'tempoyak', 'tempoyak', id, 'Tempoyak dimakan samo ikan', 'Tempoyak dimakan dengan ikan'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'tekwan', 'tekwan', id, 'Tekwan kuahnye seger', 'Tekwan kuahnya segar'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT 'model', 'model', id, 'Model dimakan pagi-pagi', 'Model dimakan pagi-pagi'
FROM categories WHERE slug = 'makanan';

-- ========================================
-- 6. INSERT SOAL KUIS (10 soal)
-- ========================================

-- Soal 1: nian
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "nian" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sangat', true
FROM quiz_questions q WHERE q.question LIKE '%nian%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sedikit', false
FROM quiz_questions q WHERE q.question LIKE '%nian%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'kadang', false
FROM quiz_questions q WHERE q.question LIKE '%nian%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'tidak', false
FROM quiz_questions q WHERE q.question LIKE '%nian%';

-- Soal 2: mak
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "mak" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'keluarga';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'ibu', true
FROM quiz_questions q WHERE q.question LIKE '%mak%' AND q.question NOT LIKE '%makanan%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'ayah', false
FROM quiz_questions q WHERE q.question LIKE '%mak%' AND q.question NOT LIKE '%makanan%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'kakak', false
FROM quiz_questions q WHERE q.question LIKE '%mak%' AND q.question NOT LIKE '%makanan%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'adik', false
FROM quiz_questions q WHERE q.question LIKE '%mak%' AND q.question NOT LIKE '%makanan%';

-- Soal 3: pempek
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa makanan khas Palembang yang terbuat dari ikan?', id
FROM categories WHERE slug = 'makanan';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'pempek', true
FROM quiz_questions q WHERE q.question LIKE '%makanan khas%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'rendang', false
FROM quiz_questions q WHERE q.question LIKE '%makanan khas%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sate', false
FROM quiz_questions q WHERE q.question LIKE '%makanan khas%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'bakso', false
FROM quiz_questions q WHERE q.question LIKE '%makanan khas%';

-- Soal 4: gale
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "gale" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'semua', true
FROM quiz_questions q WHERE q.question LIKE '%gale%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sedikit', false
FROM quiz_questions q WHERE q.question LIKE '%gale%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'banyak', false
FROM quiz_questions q WHERE q.question LIKE '%gale%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'tidak ada', false
FROM quiz_questions q WHERE q.question LIKE '%gale%';

-- Soal 5: manok
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "manok" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'hewan';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'ayam', true
FROM quiz_questions q WHERE q.question LIKE '%manok%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'bebek', false
FROM quiz_questions q WHERE q.question LIKE '%manok%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'burung', false
FROM quiz_questions q WHERE q.question LIKE '%manok%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'ikan', false
FROM quiz_questions q WHERE q.question LIKE '%manok%';

-- Soal 6: dak
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "dak" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sudah', true
FROM quiz_questions q WHERE q.question LIKE '%"dak"%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'belum', false
FROM quiz_questions q WHERE q.question LIKE '%"dak"%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'akan', false
FROM quiz_questions q WHERE q.question LIKE '%"dak"%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sedang', false
FROM quiz_questions q WHERE q.question LIKE '%"dak"%';

-- Soal 7: embah
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "embah" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'keluarga';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'nenek', true
FROM quiz_questions q WHERE q.question LIKE '%embah%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'kakek', false
FROM quiz_questions q WHERE q.question LIKE '%embah%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'bibi', false
FROM quiz_questions q WHERE q.question LIKE '%embah%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'paman', false
FROM quiz_questions q WHERE q.question LIKE '%embah%';

-- Soal 8: cuko
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "cuko" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'makanan';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'saus pempek', true
FROM quiz_questions q WHERE q.question LIKE '%cuko%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sambal', false
FROM quiz_questions q WHERE q.question LIKE '%cuko%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'kecap', false
FROM quiz_questions q WHERE q.question LIKE '%cuko%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'saus tomat', false
FROM quiz_questions q WHERE q.question LIKE '%cuko%';

-- Soal 9: ngape
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "ngape" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'mau/akan', true
FROM quiz_questions q WHERE q.question LIKE '%ngape%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sudah', false
FROM quiz_questions q WHERE q.question LIKE '%ngape%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'belum', false
FROM quiz_questions q WHERE q.question LIKE '%ngape%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'tidak', false
FROM quiz_questions q WHERE q.question LIKE '%ngape%';

-- Soal 10: asu
INSERT INTO quiz_questions (question, category_id)
SELECT 'Apa arti kata "asu" dalam Bahasa Indonesia?', id
FROM categories WHERE slug = 'hewan';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'anjing', true
FROM quiz_questions q WHERE q.question LIKE '%"asu"%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'kucing', false
FROM quiz_questions q WHERE q.question LIKE '%"asu"%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'kambing', false
FROM quiz_questions q WHERE q.question LIKE '%"asu"%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT q.id, 'sapi', false
FROM quiz_questions q WHERE q.question LIKE '%"asu"%';

-- ========================================
-- SELESAI!
-- ========================================
-- Total:
-- - 4 Kategori
-- - 30 Kosakata (8 sehari-hari, 6 keluarga, 6 hewan, 6 makanan)
-- - 10 Soal Kuis dengan 40 Opsi

-- CATATAN: Untuk user guru/admin, buat manual di Supabase Dashboard:
-- 1. Buka Authentication → Users → Add user
-- 2. Catat UUID user
-- 3. Jalankan query: INSERT INTO profiles (id, role) VALUES ('UUID_TADI', 'guru');
