-- Seed data untuk Media Pembelajaran Bahasa Palembang
-- Data ini adalah CONTOH untuk keperluan development dan testing
-- GANTI dengan data dari Buku Baso Pelembang Kelas 3 dan hasil wawancara guru

-- Insert Kategori
INSERT INTO categories (name, slug, sort_order) VALUES
  ('Sehari-hari', 'sehari-hari', 1),
  ('Keluarga', 'keluarga', 2),
  ('Hewan', 'hewan', 3),
  ('Makanan', 'makanan', 4);

-- CONTOH Kosakata - GANTI dengan data asli dari buku dan wawancara
-- Kategori: Sehari-hari
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'nian',
  'sangat',
  id,
  'Panas nian ari ini',
  'Sangat panas hari ini'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'gale',
  'semua',
  id,
  'Gale wong dak mandi',
  'Semua orang sudah mandi'
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'kemane',
  'kemana',
  id,
  'Kau ngape kemane?',
  'Kamu mau pergi kemana?'
FROM categories WHERE slug = 'sehari-hari';

-- Kategori: Keluarga
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'ayah',
  'ayah/bapak',
  id,
  'Ayah kerje di kanto',
  'Ayah bekerja di kantor'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'mak',
  'ibu',
  id,
  'Mak masak di dapu',
  'Ibu memasak di dapur'
FROM categories WHERE slug = 'keluarga';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'kakak',
  'kakak',
  id,
  'Kakak sekolah di SMP',
  'Kakak sekolah di SMP'
FROM categories WHERE slug = 'keluarga';

-- Kategori: Hewan
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'kucing',
  'kucing',
  id,
  'Kucing ni lucu nian',
  'Kucing ini sangat lucu'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'asu',
  'anjing',
  id,
  'Asu kesayanganku ilang',
  'Anjing kesayanganku hilang'
FROM categories WHERE slug = 'hewan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'manok',
  'ayam',
  id,
  'Manok beranak banyak',
  'Ayam bertelur banyak'
FROM categories WHERE slug = 'hewan';

-- Kategori: Makanan
INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'pempek',
  'pempek',
  id,
  'Aku suke pempek kapal selam',
  'Aku suka pempek kapal selam'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'cuko',
  'saus pempek',
  id,
  'Cuko ni pedes nian',
  'Saus ini sangat pedas'
FROM categories WHERE slug = 'makanan';

INSERT INTO words (palembang, indonesia, category_id, example_palembang, example_indonesia)
SELECT
  'kemplang',
  'kerupuk kemplang',
  id,
  'Kemplang enak dimakan samo cuko',
  'Kemplang enak dimakan dengan cuko'
FROM categories WHERE slug = 'makanan';

-- CONTOH Soal Kuis - GANTI dengan soal yang sesuai dengan materi pembelajaran
INSERT INTO quiz_questions (question, category_id)
SELECT 
  'Apa arti kata "nian" dalam Bahasa Indonesia?',
  id
FROM categories WHERE slug = 'sehari-hari';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'sangat',
  true
FROM quiz_questions q WHERE q.question LIKE '%nian%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'sedikit',
  false
FROM quiz_questions q WHERE q.question LIKE '%nian%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'kadang',
  false
FROM quiz_questions q WHERE q.question LIKE '%nian%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'tidak',
  false
FROM quiz_questions q WHERE q.question LIKE '%nian%';

-- Soal kedua
INSERT INTO quiz_questions (question, category_id)
SELECT 
  'Apa arti kata "mak" dalam Bahasa Indonesia?',
  id
FROM categories WHERE slug = 'keluarga';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'ibu',
  true
FROM quiz_questions q WHERE q.question LIKE '%mak%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'ayah',
  false
FROM quiz_questions q WHERE q.question LIKE '%mak%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'kakak',
  false
FROM quiz_questions q WHERE q.question LIKE '%mak%';

INSERT INTO quiz_options (question_id, option_text, is_correct)
SELECT 
  q.id,
  'adik',
  false
FROM quiz_questions q WHERE q.question LIKE '%mak%';

-- CATATAN PENTING:
-- Setelah menjalankan migration dan seed ini, buatlah user guru dengan langkah:
-- 1. Daftar user melalui Supabase Auth (bisa via UI atau SQL)
-- 2. Tambahkan user ke tabel profiles dengan query:
--    INSERT INTO profiles (id, role) VALUES ('<user_uuid>', 'guru');
