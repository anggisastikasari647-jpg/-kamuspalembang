-- Migration 001: Inisialisasi database untuk Media Pembelajaran Bahasa Palembang
-- Dibuat untuk Tugas Akhir D3 Manajemen Informatika Universitas Sriwijaya

-- Enable Row Level Security (RLS) di semua tabel

-- TABEL: categories (Kategori Kosakata)
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  sort_order INT NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_categories_sort_order ON categories(sort_order);

-- TABEL: words (Kosakata)
CREATE TABLE words (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  palembang TEXT NOT NULL,
  indonesia TEXT NOT NULL,
  category_id UUID NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
  example_palembang TEXT,
  example_indonesia TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_words_search ON words USING GIN (
  to_tsvector('simple', palembang || ' ' || indonesia)
);
CREATE INDEX idx_words_category_id ON words(category_id);

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_words_updated_at
  BEFORE UPDATE ON words
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- TABEL: quiz_questions (Soal Kuis)
CREATE TABLE quiz_questions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question TEXT NOT NULL,
  category_id UUID REFERENCES categories(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_quiz_questions_category_id ON quiz_questions(category_id);

-- TABEL: quiz_options (Opsi Jawaban Kuis)
CREATE TABLE quiz_options (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id UUID NOT NULL REFERENCES quiz_questions(id) ON DELETE CASCADE,
  option_text TEXT NOT NULL,
  is_correct BOOLEAN NOT NULL DEFAULT FALSE
);

CREATE INDEX idx_quiz_options_question_id ON quiz_options(question_id);

-- TABEL: profiles (Profil Guru/Admin)
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'guru' CHECK (role IN ('guru', 'admin'))
);

-- FUNCTION: is_staff() untuk memeriksa apakah user adalah staff
CREATE OR REPLACE FUNCTION is_staff()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles
    WHERE id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ROW LEVEL SECURITY POLICIES

-- Categories: SELECT publik, INSERT/UPDATE/DELETE hanya staff
ALTER TABLE categories ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Categories dapat dibaca oleh semua"
  ON categories FOR SELECT
  USING (true);

CREATE POLICY "Categories dapat diubah oleh staff"
  ON categories FOR ALL
  USING (is_staff());

-- Words: SELECT publik, INSERT/UPDATE/DELETE hanya staff
ALTER TABLE words ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Words dapat dibaca oleh semua"
  ON words FOR SELECT
  USING (true);

CREATE POLICY "Words dapat diubah oleh staff"
  ON words FOR ALL
  USING (is_staff());

-- Quiz Questions: SELECT publik, INSERT/UPDATE/DELETE hanya staff
ALTER TABLE quiz_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Quiz questions dapat dibaca oleh semua"
  ON quiz_questions FOR SELECT
  USING (true);

CREATE POLICY "Quiz questions dapat diubah oleh staff"
  ON quiz_questions FOR ALL
  USING (is_staff());

-- Quiz Options: SELECT publik, INSERT/UPDATE/DELETE hanya staff
ALTER TABLE quiz_options ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Quiz options dapat dibaca oleh semua"
  ON quiz_options FOR SELECT
  USING (true);

CREATE POLICY "Quiz options dapat diubah oleh staff"
  ON quiz_options FOR ALL
  USING (is_staff());

-- Profiles: hanya bisa dibaca oleh pemiliknya
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users dapat membaca profile sendiri"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users dapat update profile sendiri"
  ON profiles FOR UPDATE
  USING (auth.uid() = id);
