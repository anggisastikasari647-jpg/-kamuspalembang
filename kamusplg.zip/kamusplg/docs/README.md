# Media Pembelajaran Interaktif Bahasa Palembang

**Tugas Akhir D3 Manajemen Informatika**  
**Universitas Sriwijaya**

Media pembelajaran kosakata Bahasa Palembang berbasis mobile website untuk siswa kelas III SD Negeri 182 Palembang.

---

## 📋 Deskripsi

Aplikasi web mobile-first yang membantu siswa kelas III SD belajar kosakata Bahasa Palembang dengan fitur:

### Fitur Siswa (Publik):
- 🏠 **Beranda**: Menampilkan kategori kosakata dan akses cepat ke fitur
- 📖 **Kamus**: Daftar kosakata dengan pencarian dan filter kategori
- 🎯 **Kuis Interaktif**: 5 soal acak dengan feedback langsung dan skor akhir
- ✅ **Hasil Kuis**: Skor visual, motivasi, dan daftar kesalahan (tidak disimpan)

### Fitur Admin/Guru:
- 🔐 **Login**: Autentikasi dengan email dan password
- 📚 **Kelola Kosakata**: CRUD kosakata dengan kategori dan contoh kalimat
- 🏷️ **Kelola Kategori**: CRUD kategori kosakata
- ❓ **Kelola Soal Kuis**: CRUD soal pilihan ganda dengan 4 opsi

**Catatan Penting**:
- Siswa TIDAK perlu login dan data mereka TIDAK disimpan
- Skor kuis hanya ditampilkan di layar, tidak ada riwayat atau analitik

---

## 🛠️ Tech Stack

- **Framework**: Next.js 14+ (App Router)
- **Language**: TypeScript (strict mode)
- **Styling**: Tailwind CSS dengan design tokens
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth (email + password)
- **Security**: Row Level Security (RLS)
- **Validation**: Zod
- **Forms**: React Hook Form (admin)
- **Font**: Nunito (Google Fonts)
- **Deployment**: Vercel
- **Package Manager**: npm

---

## 🚀 Instalasi & Setup

### 1. Prerequisites

- Node.js 18+ dan npm
- Akun Supabase
- Git (opsional)

### 2. Clone atau Download Project

```bash
# Jika menggunakan Git
git clone <repository-url>
cd kamusplg

# Atau download ZIP dan ekstrak
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Setup Supabase

#### a. Buat Project Supabase
1. Buka [https://supabase.com/dashboard](https://supabase.com/dashboard)
2. Klik "New Project"
3. Isi nama project, database password, dan region
4. Tunggu hingga project selesai dibuat

#### b. Jalankan Migration Database
1. Di Supabase Dashboard, buka **SQL Editor**
2. Klik "New Query"
3. Copy seluruh isi file `supabase/migrations/001_init.sql`
4. Paste di SQL Editor dan klik "Run"
5. Pastikan semua tabel berhasil dibuat

#### c. Jalankan Seed Data (Opsional)
1. Di SQL Editor, buat query baru
2. Copy seluruh isi file `supabase/seed.sql`
3. Paste dan klik "Run"
4. Data contoh kategori, kosakata, dan soal akan dibuat

#### d. Buat User Guru/Admin
1. Di Supabase Dashboard, buka **Authentication** → **Users**
2. Klik "Add user" → "Create new user"
3. Isi email dan password (contoh: `guru@example.com`)
4. Setelah user dibuat, catat **User UID** (klik user untuk melihat)
5. Di **SQL Editor**, jalankan query berikut (ganti `USER_UID` dengan UID yang dicatat):

```sql
INSERT INTO profiles (id, role) VALUES ('USER_UID', 'guru');
```

#### e. Ambil API Keys
1. Di Supabase Dashboard, buka **Settings** → **API**
2. Catat:
   - **Project URL** (contoh: `https://xxx.supabase.co`)
   - **anon public** key (panjang, diawali `eyJ...`)

### 5. Setup Environment Variables

1. Copy file `.env.example` menjadi `.env.local`:

```bash
cp .env.example .env.local
```

2. Edit `.env.local` dan isi dengan credentials Supabase:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 6. Jalankan Development Server

```bash
npm run dev
```

Aplikasi akan berjalan di [http://localhost:3000](http://localhost:3000)

### 7. Akses Aplikasi

- **Halaman Siswa**: [http://localhost:3000](http://localhost:3000)
- **Login Admin**: [http://localhost:3000/admin/login](http://localhost:3000/admin/login)
  - Email: sesuai yang dibuat di langkah 4.d
  - Password: sesuai yang dibuat di langkah 4.d

---

## 📦 Deploy ke Vercel

### 1. Push ke Git Repository (GitHub/GitLab)

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin <your-repo-url>
git push -u origin main
```

### 2. Import ke Vercel

1. Buka [https://vercel.com](https://vercel.com)
2. Klik "Add New Project"
3. Import repository yang sudah dibuat
4. Tambahkan **Environment Variables**:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
5. Klik "Deploy"

### 3. Selesai!

Aplikasi akan tersedia di URL Vercel (contoh: `https://kamusplg.vercel.app`)

---

## 📱 Cara Menggunakan

### Untuk Siswa:

1. Buka aplikasi di browser (Chrome/Safari/Firefox)
2. Di **Beranda**: lihat kategori dan klik kategori untuk melihat kata-kata
3. Di **Kamus**: cari kata atau filter berdasarkan kategori
4. Di **Kuis**: klik "Main Kuis" dan jawab 5 soal, lihat hasil di akhir

### Untuk Guru/Admin:

1. Buka `/admin/login` dan masuk dengan email/password
2. **Kelola Kosakata**: tambah, ubah, atau hapus kata beserta contoh kalimat
3. **Kelola Kategori**: tambah atau ubah kategori (hapus hanya jika tidak ada kata)
4. **Kelola Soal**: tambah soal pilihan ganda dengan 4 opsi (1 benar)
5. Klik **Keluar** di header untuk logout

---

## 🎨 Design System

### Warna:
- **Primary** (Merah Songket): `#8E1B2B`
- **Accent** (Emas): `#F2B33D`
- **Background** (Krem): `#FFF8EA`
- **Text Primary**: `#2B1A12`
- **Border**: `#E8D5B0`

### Typography:
- **Font**: Nunito (500, 700, 800)
- **Heading 1**: 2rem, 800 weight
- **Heading 2**: 1.5rem, 700 weight
- **Body**: 1rem, 500 weight

### Accessibility:
- Minimal touch target: 48px
- Kontras teks minimal: 4.5:1
- Semantic HTML
- ARIA labels pada komponen interaktif

---

## 🗂️ Struktur Project

```
kamusplg/
├── app/
│   ├── (siswa)/              # Route group untuk siswa
│   │   ├── page.tsx          # Beranda
│   │   ├── kamus/            # Halaman kamus
│   │   └── kuis/             # Halaman kuis
│   ├── admin/
│   │   ├── login/            # Login admin
│   │   └── (panel)/          # Panel admin dengan proteksi
│   ├── api/                  # API routes
│   └── globals.css
├── components/
│   ├── ui/                   # Komponen UI dasar
│   ├── siswa/                # Komponen khusus siswa
│   └── admin/                # Komponen khusus admin
├── lib/
│   ├── supabase/             # Supabase clients
│   ├── utils/                # Utility functions
│   └── validators/           # Zod schemas
├── services/                 # Data access layer
├── types/                    # TypeScript types
├── supabase/
│   ├── migrations/           # SQL migrations
│   └── seed.sql              # Seed data
└── docs/                     # Dokumentasi
```

---

## ⚠️ Catatan Penting

### Data Contoh:
File `seed.sql` berisi data CONTOH yang harus diganti dengan:
- Data dari **Buku Baso Pelembang Kelas 3**
- Hasil wawancara dengan guru SD Negeri 182 Palembang

### Keamanan:
- **JANGAN** commit file `.env.local`
- **JANGAN** share Supabase Service Role Key (hanya gunakan Anon Key)
- RLS sudah aktif di semua tabel untuk keamanan data

### Browser Support:
- Chrome 90+
- Safari 14+
- Firefox 88+
- Edge 90+

---

## 🐛 Troubleshooting

### Error: "Failed to fetch" di halaman siswa
- Cek apakah migration sudah dijalankan di Supabase
- Pastikan RLS policies sudah dibuat
- Cek environment variables di `.env.local`

### Error: "You do not have access" saat login admin
- Pastikan user sudah ditambahkan ke tabel `profiles`
- Jalankan query di SQL Editor:
  ```sql
  SELECT * FROM profiles WHERE id = 'USER_UID';
  ```

### Kategori tidak bisa dihapus
- Normal jika kategori masih memiliki kata
- Hapus atau pindahkan kata terlebih dahulu

---

## 📞 Kontak

Untuk pertanyaan teknis atau masalah, hubungi:
- **Mahasiswa**: [Nama Mahasiswa]
- **Email**: [email@example.com]
- **Dosen Pembimbing**: [Nama Dosen]

---

## 📄 Lisensi

Project ini dibuat untuk keperluan Tugas Akhir D3 Manajemen Informatika Universitas Sriwijaya.
