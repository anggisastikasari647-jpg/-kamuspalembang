# Entity Relationship Diagram (ERD)

## Diagram Relasi Database

```mermaid
erDiagram
    categories ||--o{ words : "memiliki"
    categories ||--o{ quiz_questions : "terkait"
    quiz_questions ||--|{ quiz_options : "memiliki"
    auth_users ||--|| profiles : "memiliki"

    categories {
        uuid id PK
        text name UK
        text slug UK
        int sort_order
        timestamptz created_at
    }

    words {
        uuid id PK
        text palembang
        text indonesia
        uuid category_id FK
        text example_palembang
        text example_indonesia
        timestamptz created_at
        timestamptz updated_at
    }

    quiz_questions {
        uuid id PK
        text question
        uuid category_id FK "nullable"
        timestamptz created_at
    }

    quiz_options {
        uuid id PK
        uuid question_id FK
        text option_text
        boolean is_correct
    }

    auth_users {
        uuid id PK
        text email UK
    }

    profiles {
        uuid id PK,FK
        text role "guru/admin"
    }
```

---

## Deskripsi Tabel

### 1. **categories**
Menyimpan kategori kosakata (Sehari-hari, Keluarga, Hewan, Makanan, dll).

| Kolom | Tipe | Keterangan |
|-------|------|------------|
| id | UUID | Primary key, auto-generated |
| name | TEXT | Nama kategori (unique) |
| slug | TEXT | URL-friendly version dari name (unique) |
| sort_order | INT | Urutan tampilan kategori |
| created_at | TIMESTAMPTZ | Waktu pembuatan |

**Constraint**:
- `name` dan `slug` harus unique
- `sort_order` default 0

**Relasi**:
- One-to-Many dengan `words` (satu kategori banyak kata)
- One-to-Many dengan `quiz_questions` (opsional)

---

### 2. **words**
Menyimpan kosakata Bahasa Palembang beserta artinya.

| Kolom | Tipe | Keterangan |
|-------|------|------------|
| id | UUID | Primary key, auto-generated |
| palembang | TEXT | Kata dalam Bahasa Palembang |
| indonesia | TEXT | Arti dalam Bahasa Indonesia |
| category_id | UUID | Foreign key ke `categories` |
| example_palembang | TEXT | Contoh kalimat (opsional) |
| example_indonesia | TEXT | Terjemahan contoh (opsional) |
| created_at | TIMESTAMPTZ | Waktu pembuatan |
| updated_at | TIMESTAMPTZ | Waktu terakhir diubah (auto-update) |

**Constraint**:
- `category_id` REFERENCES `categories(id)` ON DELETE RESTRICT
- Full-text search index pada kolom `palembang` dan `indonesia`

**Relasi**:
- Many-to-One dengan `categories` (banyak kata satu kategori)

---

### 3. **quiz_questions**
Menyimpan pertanyaan kuis.

| Kolom | Tipe | Keterangan |
|-------|------|------------|
| id | UUID | Primary key, auto-generated |
| question | TEXT | Pertanyaan kuis |
| category_id | UUID | Foreign key ke `categories` (nullable) |
| created_at | TIMESTAMPTZ | Waktu pembuatan |

**Constraint**:
- `category_id` REFERENCES `categories(id)` ON DELETE SET NULL

**Relasi**:
- Many-to-One dengan `categories` (opsional)
- One-to-Many dengan `quiz_options` (satu soal 4 opsi)

---

### 4. **quiz_options**
Menyimpan opsi jawaban untuk setiap soal kuis.

| Kolom | Tipe | Keterangan |
|-------|------|------------|
| id | UUID | Primary key, auto-generated |
| question_id | UUID | Foreign key ke `quiz_questions` |
| option_text | TEXT | Teks opsi jawaban |
| is_correct | BOOLEAN | Apakah opsi ini jawaban benar |

**Constraint**:
- `question_id` REFERENCES `quiz_questions(id)` ON DELETE CASCADE
- Setiap soal harus punya tepat 4 opsi dan 1 benar (divalidasi di aplikasi)

**Relasi**:
- Many-to-One dengan `quiz_questions` (4 opsi per soal)

---

### 5. **profiles**
Menyimpan profil guru/admin yang bisa login.

| Kolom | Tipe | Keterangan |
|-------|------|------------|
| id | UUID | Primary key & Foreign key ke `auth.users` |
| role | TEXT | Peran: 'guru' atau 'admin' (default 'guru') |

**Constraint**:
- `id` REFERENCES `auth.users(id)` ON DELETE CASCADE
- `role` CHECK (role IN ('guru', 'admin'))

**Relasi**:
- One-to-One dengan `auth.users` (satu user satu profile)

---

## Row Level Security (RLS)

### Policies:

#### **categories**, **words**, **quiz_questions**, **quiz_options**:
- **SELECT**: Semua orang (publik, termasuk anonymous) ✅
- **INSERT/UPDATE/DELETE**: Hanya staff (user yang ada di `profiles`) ✅

#### **profiles**:
- **SELECT**: Hanya user sendiri ✅
- **UPDATE**: Hanya user sendiri ✅

### Security Function:

```sql
CREATE FUNCTION is_staff() RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM profiles WHERE id = auth.uid()
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;
```

Fungsi ini digunakan di policy untuk memeriksa apakah user saat ini adalah staff.

---

## Catatan Desain Database

### 1. Tidak Ada Data Siswa
Sesuai requirement, **tidak ada tabel untuk menyimpan data siswa, riwayat skor, atau leaderboard**. Siswa menggunakan aplikasi tanpa login dan hasilnya tidak disimpan.

### 2. Cascade Delete
- Menghapus `quiz_questions` akan otomatis menghapus semua `quiz_options` terkait (CASCADE)
- Menghapus `categories` akan gagal jika masih ada `words` terkait (RESTRICT)
- Menghapus user dari `auth.users` akan otomatis menghapus `profiles` (CASCADE)

### 3. Indexing
- Full-text search pada `words.palembang` dan `words.indonesia` untuk pencarian cepat
- Index pada foreign keys (`category_id`, `question_id`) untuk performa join

### 4. Auto-Update
- Trigger `update_updated_at_column` otomatis mengupdate `words.updated_at` saat record diubah

### 5. Scalability
Database ini dirancang untuk:
- Ratusan hingga ribuan kosakata
- Puluhan hingga ratusan soal kuis
- Beberapa guru/admin (< 10 orang)

Untuk skala lebih besar, pertimbangkan:
- Caching dengan Redis
- Read replicas untuk query berat
- CDN untuk assets statis

---

## Contoh Query

### Ambil semua kata dengan kategori:
```sql
SELECT w.*, c.name as category_name
FROM words w
JOIN categories c ON w.category_id = c.id
ORDER BY w.palembang;
```

### Ambil soal kuis dengan opsi:
```sql
SELECT q.*, 
  json_agg(o.*) as options
FROM quiz_questions q
JOIN quiz_options o ON o.question_id = q.id
GROUP BY q.id;
```

### Cari kata:
```sql
SELECT *
FROM words
WHERE palembang ILIKE '%nian%' 
   OR indonesia ILIKE '%nian%';
```

---

Diagram ini menunjukkan struktur database yang sederhana namun lengkap untuk kebutuhan aplikasi pembelajaran Bahasa Palembang.
