# Media Pembelajaran Interaktif Bahasa Palembang

Aplikasi pembelajaran kosakata Bahasa Palembang untuk siswa kelas III SD.

## 🚀 Quick Start

1. Install dependencies:
```bash
npm install
```

2. Setup environment variables:
```bash
cp .env.example .env.local
```

Edit `.env.local` dengan Supabase credentials Anda.

3. Run development server:
```bash
npm run dev
```

Buka [http://localhost:3000](http://localhost:3000)

## 📚 Dokumentasi Lengkap

Lihat [docs/README.md](./docs/README.md) untuk dokumentasi lengkap.

## 🎓 Tugas Akhir

Dibuat untuk Tugas Akhir D3 Manajemen Informatika - Universitas Sriwijaya

**SD Negeri 182 Palembang - Kelas III**
