import { createBrowserClient } from '@supabase/ssr'
import type { Database } from '@/types/database'

/**
 * Client Supabase untuk digunakan di komponen Client Components
 * Digunakan untuk operasi yang memerlukan interaksi browser seperti auth dan real-time
 */
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  )
}
