import { z } from 'zod'

/**
 * Validator untuk satu opsi jawaban
 */
export const quizOptionSchema = z.object({
  option_text: z.string().min(1, 'Opsi jawaban harus diisi').trim(),
  is_correct: z.boolean(),
})

/**
 * Validator untuk form soal kuis
 * Validasi: harus ada 4 opsi dan tepat 1 jawaban benar
 */
export const quizQuestionSchema = z.object({
  question: z.string().min(1, 'Pertanyaan harus diisi').trim(),
  category_id: z.string().uuid('Kategori tidak valid').optional().nullable(),
  options: z.array(quizOptionSchema)
    .length(4, 'Harus ada tepat 4 opsi jawaban')
    .refine(
      (options) => options.filter(opt => opt.is_correct).length === 1,
      { message: 'Harus ada tepat 1 jawaban yang benar' }
    ),
})

export type QuizQuestionFormData = z.infer<typeof quizQuestionSchema>

/**
 * Validator untuk update soal kuis
 */
export const quizQuestionUpdateSchema = quizQuestionSchema.extend({
  id: z.string().uuid(),
})

export type QuizQuestionUpdateData = z.infer<typeof quizQuestionUpdateSchema>
