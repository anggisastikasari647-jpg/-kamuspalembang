import { z } from 'zod'

/**
 * Validator untuk form kosakata
 * Memastikan semua field required terisi dengan benar
 */
export const wordSchema = z.object({
  palembang: z.string().min(1, 'Kata Palembang harus diisi').trim(),
  indonesia: z.string().min(1, 'Arti Indonesia harus diisi').trim(),
  category_id: z.string().uuid('Kategori harus dipilih'),
  example_palembang: z.string().trim().optional().nullable(),
  example_indonesia: z.string().trim().optional().nullable(),
})

export type WordFormData = z.infer<typeof wordSchema>

/**
 * Validator untuk update kosakata (semua field opsional kecuali ID)
 */
export const wordUpdateSchema = wordSchema.partial().extend({
  id: z.string().uuid(),
})

export type WordUpdateData = z.infer<typeof wordUpdateSchema>
