import { z } from 'zod'

/**
 * Validator untuk form kategori
 */
export const categorySchema = z.object({
  name: z.string().min(1, 'Nama kategori harus diisi').trim(),
  slug: z.string().min(1, 'Slug harus diisi').trim()
    .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/, 'Slug hanya boleh huruf kecil, angka, dan dash'),
  sort_order: z.number().int().min(0, 'Urutan harus bilangan positif').default(0),
})

export type CategoryFormData = z.infer<typeof categorySchema>

/**
 * Validator untuk update kategori
 */
export const categoryUpdateSchema = categorySchema.partial().extend({
  id: z.string().uuid(),
})

export type CategoryUpdateData = z.infer<typeof categoryUpdateSchema>
