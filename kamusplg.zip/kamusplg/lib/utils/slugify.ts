/**
 * Mengkonversi string menjadi slug yang aman untuk URL
 * Contoh: "Sehari-hari" -> "sehari-hari"
 */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, '') // Hapus karakter spesial
    .replace(/[\s_-]+/g, '-') // Ganti spasi dan underscore dengan dash
    .replace(/^-+|-+$/g, '') // Hapus dash di awal dan akhir
}
