import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

/**
 * Utility function untuk menggabungkan class names dengan Tailwind
 * Menggunakan clsx untuk conditional classes dan twMerge untuk menghindari konflik
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}
